import { UserStats, UserProfile, AvatarConfig } from '../types';

const DB_KEY = 'dogdolygo_db_v1'; // The "Database" containing all users
const SESSION_KEY = 'dogdolygo_session'; // Current active session

const DEFAULT_AVATAR: AvatarConfig = {
  skinColor: '#f5d0b0',
  hairColor: '#4a3b2a',
  hairStyle: 'short',
  shirtColor: '#58cc02',
  shirtStyle: 'tshirt',
  eyeType: 'normal',
  glasses: false,
  beard: false,
  mouthType: 'smile',
  backgroundColor: '#e5e5e5'
};

const DEFAULT_STATS: UserStats = {
  streak: 0,
  gems: 100, // Starting Gama
  hearts: 5,
  totalXp: 0,
  completedLessons: [], // Initialize empty completion list
  inventory: {
    streakFreeze: false,
    unlimitedHeartsUntil: null
  },
  user: undefined,
  mistakes: []
};

// Helper to get DB
const getDB = (): Record<string, UserStats> => {
  try {
    return JSON.parse(localStorage.getItem(DB_KEY) || '{}');
  } catch { return {}; }
};

// Helper to save DB
const saveDB = (db: Record<string, UserStats>) => {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
};

export const saveState = (stats: UserStats) => {
  try {
    // 1. Save to session key (for immediate refresh/reload)
    localStorage.setItem(SESSION_KEY, JSON.stringify(stats));

    // 2. If user is logged in, sync to the persistent "Database"
    // We use username as the unique key for the database lookup
    if (stats.user && stats.user.username) {
      const db = getDB();
      db[stats.user.username] = stats;
      saveDB(db);
    }
  } catch (e) {
    console.error("Failed to save state", e);
  }
};

export const loadState = (): UserStats => {
  try {
    const saved = localStorage.getItem(SESSION_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      // Merge with default to ensure new fields exist if loading old data
      const loadedStats = { 
          ...DEFAULT_STATS, 
          ...parsed, 
          inventory: { ...DEFAULT_STATS.inventory, ...parsed.inventory },
          completedLessons: parsed.completedLessons || [],
          mistakes: parsed.mistakes || []
      };

      // Ensure user has an avatar config if logged in
      if (loadedStats.user && !loadedStats.user.avatar) {
        loadedStats.user.avatar = DEFAULT_AVATAR;
      }

      return loadedStats;
    }
  } catch (e) {
    console.error("Failed to load state", e);
  }
  return DEFAULT_STATS;
};

export const clearState = () => {
  localStorage.removeItem(SESSION_KEY);
  return DEFAULT_STATS;
};

// --- AUTHENTICATION HELPERS ---

export const registerUser = (profile: UserProfile): UserStats | null => {
  const db = getDB();
  // Check if username already exists
  if (db[profile.username]) {
    return null; // Error: User exists
  }
  
  // Ensure profile has default avatar
  const profileWithAvatar = { ...profile, avatar: DEFAULT_AVATAR };

  // Create new user entry with default stats
  const newStats = { ...DEFAULT_STATS, user: profileWithAvatar };
  
  // Save to DB
  db[profile.username] = newStats;
  saveDB(db);
  
  return newStats;
};

export const authenticateUser = (username: string, password?: string): UserStats | null => {
  const db = getDB();
  const userStats = db[username];
  
  if (userStats && userStats.user) {
    // Check password (plaintext for this local mock)
    if (userStats.user.password === password) {
        // Ensure legacy users get an avatar on login
        if (!userStats.user.avatar) {
            userStats.user.avatar = DEFAULT_AVATAR;
        }
        return userStats;
    }
  }
  return null;
};