
export enum LessonStatus {
  LOCKED = 'LOCKED',
  ACTIVE = 'ACTIVE',
  COMPLETED = 'COMPLETED',
  LEGENDARY = 'LEGENDARY'
}

export type ExerciseType = 
  | 'translation' 
  | 'listening' 
  | 'fill-gap' 
  | 'select-meaning'
  | 'listening-comprehension' // DELF Unit 1
  | 'reading-comprehension'   // DELF Unit 2
  | 'writing'                 // DELF Unit 3
  | 'speaking';               // DELF Unit 4

export interface Exercise {
  type: ExerciseType;
  question: string;
  options?: string[]; // For multiple choice
  correctAnswer?: string;
  audioText?: string; // For TTS listening
  audioUrl?: string; // For MP3 file listening
  contextText?: string; // For reading comprehension passages
  prompt?: string; // For writing/speaking prompts
  characterImage?: string; // URL for character (Dog or Cat)
}

export interface Lesson {
  id: string;
  index: number;
  type: 'star' | 'book' | 'trophy' | 'chest';
  status: LessonStatus;
  totalLevels: number;
  completedLevels: number;
  title?: string;
  exercises?: Exercise[]; // Hardcoded exam content
  isCurrent?: boolean; // To mark the next logical lesson even if others are unlocked
}

export interface Unit {
  id: string;
  number: number;
  title: string;
  description: string;
  color: string;
  lessons: Lesson[];
}

export interface AvatarConfig {
  skinColor: string;
  hairColor: string;
  hairStyle: 'short' | 'long' | 'spiky' | 'bald' | 'bob';
  shirtColor: string;
  shirtStyle: 'tshirt' | 'suit' | 'hoodie';
  eyeType: 'normal' | 'happy' | 'tired';
  glasses: boolean;
  beard: boolean;
  mouthType: 'smile' | 'neutral' | 'open';
  backgroundColor: string;
}

export interface UserProfile {
  id: string; // Unique ID for persistence identification
  username: string;
  firstName: string;
  lastName: string;
  password?: string; // Stored locally for simple auth simulation
  joinDate: string;
  avatar?: AvatarConfig;
}

export interface Inventory {
  streakFreeze: boolean;
  unlimitedHeartsUntil: number | null; // Timestamp
}

export interface Mistake {
  question: string;
  userAnswer: string;
  correctAnswer: string;
  type: string;
  timestamp: number;
}

export interface UserStats {
  streak: number;
  gems: number; // Gama
  hearts: number;
  totalXp: number;
  completedLessons: string[]; // List of IDs of completed lessons
  inventory: Inventory;
  user?: UserProfile;
  mistakes: Mistake[]; // History of user errors for AI analysis
}