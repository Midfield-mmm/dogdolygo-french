import React, { useState, useEffect, useMemo } from 'react';
import Sidebar from './components/Sidebar';
import MobileNav from './components/MobileNav';
import RightSidebar from './components/RightSidebar';
import UnitHeader from './components/UnitHeader';
import LessonNode from './components/LessonNode';
import ChatInterface from './components/ChatInterface';
import LessonOverlay from './components/LessonOverlay';
import VoiceConversationOverlay from './components/VoiceConversationOverlay';
import ZazouCallOverlay from './components/ZazouCallOverlay';
import Shop from './components/Shop';
import Profile from './components/Profile';
import Leaderboard from './components/Leaderboard';
import Practice from './components/Practice';
import CompletionModal from './components/CompletionModal';
import SettingsModal from './components/SettingsModal';
import SupportChat from './components/SupportChat';
import { MOCK_UNITS } from './constants';
import { Lesson, UserStats, LessonStatus, Mistake } from './types';
import { soundManager } from './utils/sound';
import { loadState, saveState, clearState } from './utils/storage';
import { Loader2 } from 'lucide-react';

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [activeTab, setActiveTab] = useState('learn');
  const [activeLesson, setActiveLesson] = useState<{ id: string; topic: string; lessonId: string; unitNumber: number } | null>(null);
  const [showLiveConversation, setShowLiveConversation] = useState(false);
  const [activeZazouCall, setActiveZazouCall] = useState<{ unitTitle: string; unitNumber: number; lessonId: string } | null>(null);
  const [completionData, setCompletionData] = useState<{ gems: number } | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  
  // Initialize state from local storage
  const [stats, setStats] = useState<UserStats>(loadState());

  // Splash Screen Logic
  useEffect(() => {
    const initApp = async () => {
        await new Promise(r => setTimeout(r, 100));
        soundManager.playIntro();
        setTimeout(() => {
            setShowSplash(false);
        }, 2500);
    };
    initApp();
  }, []);

  useEffect(() => {
    saveState(stats);
  }, [stats]);

  useEffect(() => {
    const checkUnlimited = () => {
        if (stats.inventory.unlimitedHeartsUntil && stats.inventory.unlimitedHeartsUntil < Date.now()) {
            setStats(prev => ({
                ...prev,
                inventory: { ...prev.inventory, unlimitedHeartsUntil: null }
            }));
        }
    };
    const interval = setInterval(checkUnlimited, 1000);
    return () => clearInterval(interval);
  }, [stats.inventory.unlimitedHeartsUntil]);

  const processedUnits = useMemo(() => {
    let firstIncompleteId: string | null = null;
    outerLoop: for (const unit of MOCK_UNITS) {
        for (const lesson of unit.lessons) {
            if (!stats.completedLessons.includes(lesson.id)) {
                firstIncompleteId = lesson.id;
                break outerLoop;
            }
        }
    }

    return MOCK_UNITS.map(unit => ({
      ...unit,
      lessons: unit.lessons.map(lesson => {
        const isCompleted = stats.completedLessons.includes(lesson.id);
        const status = isCompleted ? LessonStatus.COMPLETED : LessonStatus.ACTIVE;
        const isCurrent = lesson.id === firstIncompleteId;
        return {
          ...lesson,
          status,
          isCurrent,
          completedLevels: isCompleted ? lesson.totalLevels : 0
        };
      })
    }));
  }, [stats.completedLessons]);

  const handleLessonClick = (lesson: Lesson, unitTitle: string, unitNumber: number) => {
    const isUnlimited = stats.inventory.unlimitedHeartsUntil && stats.inventory.unlimitedHeartsUntil > Date.now();
    if (stats.hearts <= 0 && !isUnlimited) {
        soundManager.playWrong();
        alert("Plus de vies ! Allez à la boutique.");
        setActiveTab('shop');
        return;
    }

    soundManager.playPop();

    // INTERCEPTION ZAZOU : Chaque 2ème leçon (index 1)
    if (lesson.index === 1) {
        setActiveZazouCall({ unitTitle, unitNumber, lessonId: lesson.id });
        return;
    }

    const topic = lesson.title || unitTitle;
    setActiveLesson({ id: lesson.id, topic, lessonId: lesson.id, unitNumber });
  };

  const handleLessonComplete = (correctCount: number, aiScore?: number, newMistakes?: Mistake[]) => {
    const unitNumber = activeLesson?.unitNumber || activeZazouCall?.unitNumber || 1;
    const currentLessonId = activeLesson?.lessonId || activeZazouCall?.lessonId;
    let gemsEarned = 0;

    if (unitNumber === 1) gemsEarned = correctCount * 2;
    else if (unitNumber === 2) gemsEarned = correctCount * 5;
    else if (unitNumber >= 3) {
        const score = aiScore || 0;
        gemsEarned = 20 + Math.floor((score / 25) * 10);
    } else {
        gemsEarned = correctCount * 1; 
    }

    setStats(prev => {
        const newCompletedLessons = new Set(prev.completedLessons);
        if (currentLessonId && !currentLessonId.startsWith('practice_') && currentLessonId !== 'quest_writing') {
            newCompletedLessons.add(currentLessonId);
        }
        let updatedMistakes = prev.mistakes || [];
        if (newMistakes && newMistakes.length > 0) {
            updatedMistakes = [...updatedMistakes, ...newMistakes].slice(-50); 
        }
        return {
            ...prev,
            gems: prev.gems + gemsEarned,
            totalXp: prev.totalXp + 15,
            streak: prev.streak + 1,
            completedLessons: Array.from(newCompletedLessons),
            mistakes: updatedMistakes
        };
    });

    setActiveLesson(null);
    setActiveZazouCall(null);
    setCompletionData({ gems: gemsEarned });
  };

  const handleBuyItem = (item: string, cost: number) => {
      setStats(prev => {
          const newStats = { ...prev, gems: prev.gems - cost };
          if (item === 'refill_hearts') newStats.hearts = 5;
          else if (item === 'unlimited_hearts') newStats.inventory.unlimitedHeartsUntil = Date.now() + 15 * 60 * 1000;
          else if (item === 'streak_freeze') newStats.inventory.streakFreeze = true;
          return newStats;
      });
  };

  const handleLogin = (loadedStats: UserStats) => {
      setStats(loadedStats);
      saveState(loadedStats);
  };

  const handleLogout = () => {
      const reset = clearState();
      setStats(reset);
      setActiveTab('profile');
  };

  const handleStartQuest = () => {
    setActiveLesson({
      id: 'quest_writing',
      topic: 'Mission: Rédaction IA',
      lessonId: 'quest_writing',
      unitNumber: 3
    });
  };

  const renderContent = () => {
    if (activeTab === 'ai-tutor') return <ChatInterface />;
    if (activeTab === 'shop') return <Shop stats={stats} onBuy={handleBuyItem} />;
    if (activeTab === 'profile') return <Profile stats={stats} onLogin={handleLogin} onLogout={handleLogout} />;
    if (activeTab === 'leaderboards') return <Leaderboard stats={stats} onStartQuest={handleStartQuest} />;
    if (activeTab === 'practice') return (
      <Practice 
        onStart={(id, title) => setActiveLesson({ id, topic: title, lessonId: id, unitNumber: 1 })} 
        onStartLive={() => setShowLiveConversation(true)}
      />
    );

    if (activeTab === 'learn') {
      const streakGoal = 7;
      const isStreakCompleted = stats.streak >= streakGoal;
      return (
        <div className="max-w-[600px] mx-auto pt-6 px-4 pb-32 relative">
          <div className="xl:hidden absolute top-0 right-4 z-40">
             <button onClick={() => setShowSettings(true)} className="p-1 bg-white border-2 border-gray-200 rounded-xl hover:bg-gray-50 shadow-sm overflow-hidden">
                 <img src="https://postimg.cc/4HzzhkQ8" alt="Settings" className="w-8 h-8 rounded-full object-cover" />
             </button>
          </div>
          <div className="mb-8 border-2 border-gray-200 rounded-2xl p-4 flex items-center justify-between bg-white shadow-sm overflow-hidden relative">
            <div className="z-10 flex-1 pr-4">
                <h3 className="font-extrabold text-lg text-gray-700 mb-1 flex items-center gap-2">
                    Feu Sacré <span className="text-orange-500">🔥</span>
                </h3>
                {isStreakCompleted ? (
                    <div>
                        <p className="text-sm text-gray-500 font-bold mb-3">Badge exclusif débloqué !</p>
                         <div className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-lg text-xs font-extrabold inline-block uppercase tracking-wide">Champion</div>
                    </div>
                ) : (
                    <div>
                         <p className="text-sm text-gray-500 font-medium mb-3">Série de {streakGoal} jours.</p>
                         <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
                             <div className="h-full bg-orange-500 transition-all duration-500" style={{ width: `${Math.min(100, (stats.streak / streakGoal) * 100)}%` }} />
                         </div>
                         <p className="text-orange-500 font-bold text-xs mt-1 uppercase tracking-wide">{stats.streak} / {streakGoal} jours</p>
                    </div>
                )}
            </div>
            <div className="w-24 h-24 flex items-center justify-center relative">
                 {isStreakCompleted ? (
                    <img src="https://d35aaqx5ub95lt.cloudfront.net/images/goals/2b5a211d830a24fab92e291d50f65d1d.svg" alt="Badge" className="w-20 h-20 animate-bounce" />
                 ) : (
                    <img src="https://d35aaqx5ub95lt.cloudfront.net/images/goals/df7eda7cc1cc833ba30cd1e82781b68f.svg" alt="Goal" className="w-24 h-24 object-contain" />
                 )}
            </div>
          </div>
          {processedUnits.map((unit) => (
            <div key={unit.id} className="mb-12 relative">
              {unit.number === 1 && (
                  <div className="hidden md:block absolute top-20 -right-16 lg:-right-32 xl:-right-48 z-10 animate-in slide-in-from-right duration-1000">
                      <img src="https://i.postimg.cc/K8NSnBdy/Screenshot-2025-12-07-10-58-51-Photoroom.png" alt="Character" className="w-32 lg:w-40 h-auto drop-shadow-lg transform rotate-[-5deg]" />
                  </div>
              )}
              {unit.number === 2 && (
                  <div className="hidden md:block absolute top-20 -left-16 lg:-left-32 xl:-left-48 z-10 animate-in slide-in-from-left duration-1000">
                      <img src="https://i.postimg.cc/BtfZWj3Z/Gemini-Generated-Image-lpndeplpndeplpnd-(1).png" alt="Character Unit 2" className="w-32 lg:w-40 h-auto drop-shadow-lg transform rotate-[5deg]" />
                  </div>
              )}
              {unit.number === 3 && (
                  <div className="hidden md:block absolute top-20 -right-16 lg:-right-32 xl:-right-48 z-10 animate-in slide-in-from-right duration-1000">
                      <img src="https://i.postimg.cc/8P3McSdW/1m.png" alt="Character Unit 3" className="w-32 lg:w-40 h-auto drop-shadow-lg transform rotate-[-5deg]" />
                  </div>
              )}
              <UnitHeader unit={unit} colorClass={unit.color} />
              <div className="flex flex-col items-center">
                {unit.lessons.map((lesson) => (
                  <LessonNode 
                    key={lesson.id} 
                    lesson={lesson} 
                    colorClass={unit.color.replace('bg-', 'bg-')} 
                    onClick={() => handleLessonClick(lesson, unit.title, unit.number)}
                  />
                ))}
              </div>
            </div>
          ))}
          <div className="flex justify-center mt-8 text-gray-400">
            <div className="bg-gray-200 rounded-full p-4 mb-8">
               <img src="https://d35aaqx5ub95lt.cloudfront.net/images/duo-sleeping.svg" alt="End" className="w-16 h-16 opacity-50 grayscale" />
            </div>
          </div>
        </div>
      );
    }
    return <div className="flex items-center justify-center h-screen text-gray-400 font-bold text-xl">Coming Soon</div>;
  };

  if (showSplash) {
      return (
          <div className="fixed inset-0 z-[100] bg-duo-green flex flex-col items-center justify-center animate-in fade-in duration-500">
             <div className="relative">
                 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-white/20 rounded-full blur-3xl animate-pulse"></div>
                 <img src="https://i.postimg.cc/K8NSnBdy/Screenshot-2025-12-07-10-58-51-Photoroom.png" alt="DogDolyGO!" className="w-48 h-48 object-contain relative z-10 animate-bounce" />
             </div>
             <h1 className="text-5xl font-extrabold text-white mt-8 tracking-tighter drop-shadow-md">DogDolyGO!</h1>
             <p className="text-white/80 font-bold mt-2 text-lg">Chargement...</p>
          </div>
      );
  }

  return (
    <div className="min-h-screen bg-white text-gray-800 font-sans animate-in fade-in duration-500">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="lg:pl-64 xl:pr-80 min-h-screen">{renderContent()}</main>
      <SupportChat visible={activeTab === 'learn'} />
      <RightSidebar stats={stats} onOpenSettings={() => setShowSettings(true)} />
      <MobileNav activeTab={activeTab} setActiveTab={setActiveTab} />
      {activeLesson && (
        <LessonOverlay topic={activeLesson.topic} lessonId={activeLesson.lessonId} unitNumber={activeLesson.unitNumber} onClose={() => setActiveLesson(null)} onComplete={handleLessonComplete} userMistakes={stats.mistakes} />
      )}
      {showLiveConversation && <VoiceConversationOverlay onClose={() => setShowLiveConversation(false)} />}
      {activeZazouCall && (
        <ZazouCallOverlay unitTitle={activeZazouCall.unitTitle} unitNumber={activeZazouCall.unitNumber} onClose={() => setActiveZazouCall(null)} onComplete={handleLessonComplete} />
      )}
      {completionData && <CompletionModal gems={completionData.gems} onClose={() => setCompletionData(null)} />}
      {showSettings && <SettingsModal stats={stats} onClose={() => setShowSettings(false)} onLogout={handleLogout} />}
    </div>
  );
};

export default App;