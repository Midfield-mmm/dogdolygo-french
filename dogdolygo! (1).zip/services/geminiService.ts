import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { Exercise, Mistake } from "../types";

// Initialize the Gemini AI client
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const sendMessageToGemini = async (
  history: { role: 'user' | 'model'; parts: { text: string }[] }[],
  newMessage: string
): Promise<string> => {
  try {
    if (!apiKey) {
        return "Error: API Key is missing.";
    }

    const model = 'gemini-2.5-flash';
    
    const chat = ai.chats.create({
      model: model,
      history: history,
      config: {
        systemInstruction: "You are Duo, a helpful language tutor. The user speaks Thai and is learning French. Respond in simple French, but use Thai for explanations if the user seems confused.",
      }
    });

    const response: GenerateContentResponse = await chat.sendMessage({
        message: newMessage
    });

    return response.text || "Désolé, je ne comprends pas.";
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    return "Something went wrong.";
  }
};

// --- SUPPORT CHAT WITH SEARCH GROUNDING ---

export const askSupportBot = async (query: string): Promise<string> => {
  if (!apiKey) return "API Key is missing.";
  try {
    // We append the site operator to force Google Search to look at the specific URL
    const targetSite = "https://attrape-sucrerie.my.canva.site/hfyryyryrfytyf";
    const enhancedQuery = `${query} site:${targetSite}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: enhancedQuery,
      config: {
        systemInstruction: `You are the official support bot for DogDolyGO!. 
        You MUST answer the user's question by searching for information ONLY on the website: ${targetSite}.
        If the information is not found in the search results from that specific site, politely say you don't know the answer.
        Do not make up information.`,
        tools: [{ googleSearch: {} }],
      },
    });

    // We prioritize the text response. 
    // In a full implementation, we could also parse response.candidates[0].groundingMetadata to show sources,
    // but the prompt implies a simple chatbot response.
    return response.text || "Je n'ai pas trouvé d'information à ce sujet sur le site officiel.";
  } catch (error) {
    console.error("Support Bot Error:", error);
    return "Désolé, je ne peux pas rechercher l'information pour le moment.";
  }
};

// --- NEW DELF FEATURES ---

export const generateWritingPrompt = async (): Promise<string> => {
  if (!apiKey) return "Écrivez sur vos dernières vacances.";
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: "Generate a single unique DELF B1 writing topic (Production Écrite). It should be a clear instruction in French (e.g., 'Vous avez reçu ce mail, répondez...', 'Racontez un souvenir...'). Return ONLY the French instruction, no other text.",
    });
    return response.text || "Racontez un voyage marquant.";
  } catch (e) {
    return "Racontez un événement important de votre vie.";
  }
};

export const evaluateWriting = async (text: string, prompt: string): Promise<string> => {
  if (!apiKey) return "API Key missing for evaluation.";
  try {
    const systemPrompt = `Act as a strict French DELF B1 examiner. 
    Analyze the following text based on the prompt: "${prompt}".
    The text should be around 160-180 words.
    
    Provide:
    1. A short overall comment (in French).
    2. List 3 major grammar or vocabulary errors with corrections.
    3. A score out of 25 (Format: Score: X/25).
    
    Keep it concise.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        { role: 'user', parts: [{ text: systemPrompt + "\n\nStudent Text:\n" + text }] }
      ]
    });
    return response.text || "Erreur d'analyse.";
  } catch (e) {
    return "Service unavailable.";
  }
};

export const generateSpeakingPrompt = async (): Promise<string> => {
    if (!apiKey) return "Présentez-vous.";
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: "Generate a single unique DELF B1 speaking topic (Production Orale - Monologue suivi). E.g., presenting a project, a dream, a book, or an opinion. Return ONLY the French instruction, no other text.",
      });
      return response.text || "Présentez votre livre préféré.";
    } catch (e) {
      return "Présentez votre meilleur ami.";
    }
  };

export const evaluateSpeaking = async (audioBase64: string, prompt: string): Promise<string> => {
  if (!apiKey) return "API Key missing.";
  try {
     const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: {
            parts: [
                { text: `
                Role: French Pronunciation Coach.
                Task: Analyze the user's audio response to the prompt: "${prompt}".
                
                Steps:
                1. Transcribe exactly what the user said (Speech-to-Text).
                2. Compare it with the target text requested in the prompt (ignore instructions like "Prononcez :" or "Dites :").
                3. If the user said the wrong word entirely, state it clearly (e.g., "Tu as dit 'Chat' au lieu de 'Chien'").
                4. If the word is correct but pronunciation is imperfect, specify which sounds (phonemes) were wrong.
                5. Provide encouraging feedback in French.
                6. Assign a Score out of 25 (Format: "Score: X/25").
                ` },
                { inlineData: { mimeType: "audio/webm", data: audioBase64 } }
            ]
        }
     });
     return response.text || "Erreur d'analyse audio.";
  } catch (e) {
      console.error(e);
      return "Could not analyze audio. Make sure the recording is valid.";
  }
};

// --- PERSONALIZED LESSON GENERATOR (NEW) ---

export const generatePersonalizedLesson = async (mistakes: Mistake[]): Promise<Exercise[]> => {
    if (!apiKey) return [];
    
    const mistakesJson = JSON.stringify(mistakes.map(m => ({ 
        question: m.question, 
        userAnswer: m.userAnswer, 
        correctAnswer: m.correctAnswer, 
        type: m.type 
    })));

    const prompt = `
    Act as an expert French tutor powered by Gemini 2.5 Pro.
    Analyze the following list of mistakes made by a student:
    ${mistakesJson}

    Task:
    1. Analyze the patterns in these mistakes (e.g., conjugation errors, gender agreement, vocabulary gaps).
    2. Generate exactly 15 French exercises to help the student improve on these specific weak points.
    
    Structure:
    - The FIRST exercise MUST be type "reading-comprehension". The "contextText" should be your analysis of their skills in French (addressed to the student as "Tu..."). Explain WHY they made these mistakes and what they need to work on. The question should be "As-tu compris tes erreurs ?" with options ["Oui", "Non"].
    - The remaining 14 exercises should be a mix of "fill-gap", "select-meaning", or "translation" that specifically target the identified weak points.

    Output valid JSON matching this schema:
    [
      {
        "type": "reading-comprehension" | "fill-gap" | "select-meaning" | "translation",
        "contextText": "Analysis text here (only for the first item)",
        "question": "Question text",
        "options": ["Option A", "Option B", ...],
        "correctAnswer": "Correct Option"
      },
      ...
    ]
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash", // Using flash for speed, sufficient for this task.
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                // We define the schema to ensure we get exactly what we want
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            type: { type: Type.STRING, enum: ["translation", "listening", "fill-gap", "select-meaning", "reading-comprehension"] },
                            question: { type: Type.STRING },
                            options: { type: Type.ARRAY, items: { type: Type.STRING } },
                            correctAnswer: { type: Type.STRING },
                            contextText: { type: Type.STRING }
                        },
                        required: ["type", "question", "correctAnswer", "options"]
                    }
                }
            }
        });

        if (response.text) {
            return JSON.parse(response.text) as Exercise[];
        }
        return [];
    } catch (error) {
        console.error("Personalized lesson error", error);
        throw error;
    }
};


// --- PRACTICE GENERATOR ---

export const generatePracticeExercises = async (practiceId: string): Promise<Exercise[]> => {
    if (!apiKey) return [];
    
    let prompt = "";
    
    switch (practiceId) {
        case 'practice_pronunciation':
            prompt = `Generate 25 French pronunciation exercises. 
            The first 20 should be common words or short phrases. 
            The last 5 should be "difficult" (tongue twisters or complex sounds). 
            Output valid JSON. 
            All items must be type: "speaking". 
            The "question" field should be the text the user needs to say (e.g. "Prononcez : [Word]").`;
            break;
            
        case 'practice_conjugation_present':
            prompt = `Generate 20 French fill-in-the-blank exercises specifically for PRESENT TENSE verb conjugation.
            Output valid JSON. Type: "fill-gap". 
            Question format: "Il ____ (manger) une pomme." 
            Options: ["mange", "manges", "manger"]. 
            CorrectAnswer: "mange".`;
            break;

        case 'practice_conjugation_imperfect':
            prompt = `Generate 20 French fill-in-the-blank exercises specifically for IMPERFECT TENSE (L'imparfait).
            Output valid JSON. Type: "fill-gap".
            Question format: "Quand j'étais petit, je ____ (jouer) au foot."
            Options: ["jouais", "jouait", "jouer"].
            CorrectAnswer: "jouais".`;
            break;

        case 'practice_gender_number':
            prompt = `Generate 15 French grammar exercises focusing on Masculine/Feminine and Singular/Plural agreement.
            Output valid JSON. Type: "fill-gap" or "select-meaning".
            Example: "C'est une ____ (beau) maison." -> Options: ["belle", "beau", "beaux"]. Correct: "belle".`;
            break;

        case 'practice_determinants':
            prompt = `Generate 15 French exercises on Determinants (le, la, les, un, une, des, du, de la).
            Output valid JSON. Type: "fill-gap".
            Example: "Je veux ____ pomme." -> Options: ["une", "un", "du"]. Correct: "une".`;
            break;

        case 'practice_homophones':
            prompt = `Generate 25 French exercises on Homophones (a/à, et/est, son/sont, ce/se, ou/où).
            Output valid JSON. Type: "fill-gap".
            Example: "Il ____ (a/à) faim." -> Options: ["a", "à"]. Correct: "a".`;
            break;

        case 'practice_verbs_general':
        default:
            prompt = `Generate 10 mixed French verb exercises (conjugation, meaning). Output valid JSON.`;
            break;
    }

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            type: { type: Type.STRING, enum: ["translation", "listening", "fill-gap", "select-meaning", "speaking"] },
                            question: { type: Type.STRING },
                            options: { type: Type.ARRAY, items: { type: Type.STRING } },
                            correctAnswer: { type: Type.STRING },
                            audioText: { type: Type.STRING }
                        },
                        required: ["type", "question", "correctAnswer"]
                    }
                }
            }
        });

        if (response.text) {
            return JSON.parse(response.text) as Exercise[];
        }
        return [];
    } catch (error) {
        console.error("Practice gen error", error);
        return [];
    }
};

// --- EXISTING EXERCISE GENERATOR ---

export const generateLessonExercises = async (topic: string): Promise<Exercise[]> => {
  try {
    if (!apiKey) return [];
    
    // Updated prompt for 15 exercises, Thai context, and specific vocabulary structure
    const prompt = `
    Create exactly 15 French exercises about "${topic}" for a Thai speaker learning French.
    
    Requirements:
    1. **Vocabulary Focus**: Introduce 7 specific new vocabulary words related to the topic.
    2. **Format 1**: Include at least 3 exercises asking "Comment dit-on '[Thai Word]' ?" (e.g., "Comment dit-on 'Téléphone' ?") with French options.
    3. **Format 2**: Include Translation exercises (Thai sentence -> Select French translation).
    4. **Format 3**: Include Meaning exercises (French sentence -> Select Thai meaning).
    5. **Language**: The user is a Thai speaker. The 'question' or 'options' should contain Thai text where appropriate for translation exercises.
    
    Return valid JSON.
    `;
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              type: { type: Type.STRING, enum: ["translation", "listening", "fill-gap", "select-meaning"] },
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswer: { type: Type.STRING },
              audioText: { type: Type.STRING }
            },
            required: ["type", "question", "correctAnswer", "options"]
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as Exercise[];
    }
    return [];
  } catch (error) {
    console.error("Gen lesson error", error);
    return [];
  }
};