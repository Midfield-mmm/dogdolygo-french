
// Frequency map for notes used in the sound effects
const NOTE_FREQS: Record<string, number> = {
  "C3": 130.81,
  "C4": 261.63, "C#4": 277.18, "D4": 293.66, "D#4": 311.13, "E4": 329.63, "F4": 349.23, "F#4": 369.99, "G4": 392.00, "G#4": 415.30, "A4": 440.00, "A#4": 466.16, "B4": 493.88,
  "C5": 523.25, "C#5": 554.37, "D5": 587.33, "D#5": 622.25, "E5": 659.25, "F5": 698.46, "F#5": 739.99, "G5": 783.99, "G#5": 830.61, "A5": 880.00, "A#5": 932.33, "B5": 987.77,
  "C6": 1046.50, "C#6": 1108.73, "D6": 1174.66, "D#6": 1244.51, "E6": 1318.51, "F6": 1396.91, "F#6": 1479.98, "G6": 1567.98, "G#6": 1661.22, "A6": 1760.00, "A#6": 1864.66, "B6": 1975.53,
  "C7": 2093.00, "D7": 2349.32, "E7": 2637.02
};

class SoundManager {
  private context: AudioContext | null = null;

  private getContext(): AudioContext {
    if (!this.context) {
      this.context = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return this.context;
  }

  // Helper to play a single tone
  private playTone(freq: number, startTime: number, duration: number, type: OscillatorType = 'sine', volume: number = 0.1) {
    try {
        const ctx = this.getContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = type;
        osc.frequency.value = freq;

        osc.connect(gain);
        gain.connect(ctx.destination);

        // Envelope
        gain.gain.setValueAtTime(0, startTime);
        gain.gain.linearRampToValueAtTime(volume, startTime + 0.02); // Attack
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration); // Decay/Release

        osc.start(startTime);
        osc.stop(startTime + duration + 0.1);
    } catch (e) {
        console.error("Audio error", e);
    }
  }

  // Replaces Tone.js logic:
  // Tic: Triangle, C3, attack 0.001, decay 0.15
  // Pif: Sine, D4, attack 0.01, decay 0.9 (starts 200ms later)
  playIntro() {
    try {
        const ctx = this.getContext();
        if (ctx.state === 'suspended') ctx.resume();
        const now = ctx.currentTime;

        // 1. TIC (C3 Triangle)
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'triangle';
        osc1.frequency.value = NOTE_FREQS["C3"];
        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        
        gain1.gain.setValueAtTime(0, now);
        gain1.gain.linearRampToValueAtTime(0.3, now + 0.005); 
        gain1.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
        
        osc1.start(now);
        osc1.stop(now + 0.2);

        // 2. PIFFFF (D4 Sine, +200ms)
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.value = NOTE_FREQS["D4"];
        osc2.connect(gain2);
        gain2.connect(ctx.destination);

        const start2 = now + 0.2;
        gain2.gain.setValueAtTime(0, start2);
        gain2.gain.linearRampToValueAtTime(0.4, start2 + 0.02);
        gain2.gain.exponentialRampToValueAtTime(0.01, start2 + 0.9);

        osc2.start(start2);
        osc2.stop(start2 + 1.0);
    } catch (e) {
        console.error("Intro sound error", e);
    }
  }

  playPop() {
    this.playTone(600, this.getContext().currentTime, 0.1, 'sine', 0.1);
  }

  playCorrect() {
    const now = this.getContext().currentTime;
    this.playTone(NOTE_FREQS["C5"], now, 0.1, 'sine', 0.1);
    this.playTone(NOTE_FREQS["E5"], now + 0.1, 0.2, 'sine', 0.1);
  }

  playWrong() {
    const now = this.getContext().currentTime;
    this.playTone(200, now, 0.3, 'sawtooth', 0.1);
  }

  playComplete() {
    const ctx = this.getContext();
    if (ctx.state === 'suspended') ctx.resume();

    let time = ctx.currentTime;
    const volume = 0.15;

    // 1. Accords puissants
    const chords = [
        ["C4","E4","G4"], ["D4","F4","A4"], ["E4","G4","B4"],
        ["F4","A4","C5"], ["G4","B4","D5"], ["A4","C5","E5"],
        ["B4","D5","F5"]
    ];
    chords.forEach(chord => {
        chord.forEach(note => {
             if (NOTE_FREQS[note]) this.playTone(NOTE_FREQS[note], time, 0.25, 'triangle', volume);
        });
        time += 0.2;
    });

    // 2. Montée rapide
    const ascendingNotes = ["C4","E4","G4","C5","E5","G5","C6"];
    ascendingNotes.forEach(note => {
        if (NOTE_FREQS[note]) this.playTone(NOTE_FREQS[note], time, 0.15, 'sine', volume);
        time += 0.1;
    });

    // 3. Mélodie rapide répétée (3x)
    const melodyNotes = ["C4","D4","E4","F4","G4","A4","B4","C5",
                        "D5","E5","F5","G5","A5","B5","C6"];
    for (let i = 0; i < 3; i++) {
        melodyNotes.forEach(note => {
            if (NOTE_FREQS[note]) this.playTone(NOTE_FREQS[note], time, 0.1, 'square', 0.05); // Lower volume for rapid square
            time += 0.05;
        });
    }

    // 4. Cascade ultra rapide
    const quickNotes = ["C4","E4","G4","B4","D5","F5","A5","C6","E6","G6"];
    quickNotes.forEach(note => {
        if (NOTE_FREQS[note]) this.playTone(NOTE_FREQS[note], time, 0.05, 'sine', volume);
        time += 0.03;
    });

    // 5. Accords courts
    const quickChords = [
        ["C4","E4","G4"], ["D4","F4","A4"], ["E4","G4","B4"],
        ["F4","A4","C5"], ["G4","B4","D5"], ["A4","C5","E5"]
    ];
    quickChords.forEach(chord => {
        chord.forEach(note => {
            if (NOTE_FREQS[note]) this.playTone(NOTE_FREQS[note], time, 0.15, 'triangle', volume);
        });
        time += 0.1;
    });

    // 6. Explosion finale
    const finalNotes = ["C6","D6","E6","F6","G6","A6","B6","C7","D7","E7"];
    finalNotes.forEach(note => {
        if (NOTE_FREQS[note]) this.playTone(NOTE_FREQS[note], time, 0.3, 'sawtooth', 0.1);
        time += 0.2;
    });

    // 7. Petites notes finales
    const endNotes = ["C5","E5","G5","C6","E6"];
    endNotes.forEach(note => {
        if (NOTE_FREQS[note]) this.playTone(NOTE_FREQS[note], time, 0.1, 'sine', volume);
        time += 0.03;
    });
  }
}

export const soundManager = new SoundManager();
