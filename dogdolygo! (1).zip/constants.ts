import { Unit, LessonStatus, Exercise, Lesson } from './types';

// --- DELF B1 CONTENT ---

// Unit 1: Listening Comprehension
const UNIT_1_EXERCISES_1: Exercise[] = [
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-1.mp3',
    question: "Qu'est-ce que Charlotte a pensé de ses vacances ?",
    options: ["Elle a adoré", "Elle était mitigée", "Elle a détesté"],
    correctAnswer: "Elle était mitigée" // Implied from context of problems
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-1.mp3',
    question: "L'un des problèmes à l'hôtel était que...",
    options: ["la chambre était trop petite.", "sa chambre n'était pas réservée.", "il n'y avait pas de salle de bain."],
    correctAnswer: "sa chambre n'était pas réservée."
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-1.mp3',
    question: "Ce que Charlotte a aimé, c'est...",
    options: ["la taille de la piscine.", "la nourriture du restaurant.", "la gentillesse des autres voyageurs."],
    correctAnswer: "la gentillesse des autres voyageurs."
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-1.mp3',
    question: "Le personnel de l'hôtel n'était pas...",
    options: ["aimable.", "nombreux.", "expérimenté."],
    correctAnswer: "expérimenté."
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-1.mp3',
    question: "Paul est d'accord pour...",
    options: ["passer ses prochaines vacances avec Charlotte.", "aider Charlotte à organiser ses prochaines vacances.", "prêter sa maison à Charlotte."],
    correctAnswer: "aider Charlotte à organiser ses prochaines vacances."
  }
];

const UNIT_1_EXERCISES_2: Exercise[] = [
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-2.mp3',
    question: "Quels objets recherche-t-on particulièrement pour les enfants sur ces sites ?",
    options: ["Des jouets.", "Des tablettes.", "Des vêtements."],
    correctAnswer: "Des jouets."
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-2.mp3',
    question: "Le don des objets sur Internet rencontre beaucoup de succès auprès...",
    options: ["des jeunes.", "des retraités.", "des femmes au foyer."],
    correctAnswer: "des jeunes."
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-2.mp3',
    question: "La qualité du service du site Consoblog.com est garantie par...",
    options: ["la précision des descriptions.", "l'obligation de publier des photos.", "les notes mises par les personnes qui récupèrent les objets."],
    correctAnswer: "les notes mises par les personnes qui récupèrent les objets."
  }
];

const UNIT_1_EXERCISES_3: Exercise[] = [
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-3.mp3',
    question: "Cette émission vise à...",
    options: ["Informer les commerçants.", "critiquer les achats en ligne.", "conseiller les consommateurs."],
    correctAnswer: "conseiller les consommateurs."
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-3.mp3',
    question: "Thierry Sagnier constate qu'Internet permet au consommateur...",
    options: ["de devenir lui-même vendeur.", "d'acheter sans perdre de temps.", "de bénéficier de services gratuits."],
    correctAnswer: "de bénéficier de services gratuits."
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-3.mp3',
    question: "Que pense Thierry Sagnier des commerçants qui vendent à moitié prix ?",
    options: ["Ils donnent une mauvaise image de la qualité.", "Ils mettent des prix trop élevés à l'origine.", "Ils préfèrent vendre sans bénéfices."],
    correctAnswer: "Ils mettent des prix trop élevés à l'origine."
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-3.mp3',
    question: "Thierry Sagnier donne un exemple de produit financé par la publicité. Lequel ?",
    options: ["Les concerts publics.", "Les films sur Internet.", "Les journaux gratuits."],
    correctAnswer: "Les journaux gratuits."
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://www.france-education-international.fr/sites/default/files/2021-05/delf-b1-tout-public-co_exercice-3.mp3',
    question: "Que pense Thierry Sagnier des offres gratuites des supermarchés ?",
    options: ["Il faut en profiter.", "Il faut être prudent.", "Il faut s'assurer de la qualité du produit."],
    correctAnswer: "Il faut s'assurer de la qualité du produit."
  }
];

const UNIT_1_EXERCISES_4: Exercise[] = [
  {
    type: 'listening-comprehension',
    audioUrl: 'https://lingua.com/mp3/listening/francais-mes-animaux-de-compagnie-eK6K4yHR9cj.mp3',
    question: "Combien la France reçoit-elle de touristes chaque année ?",
    options: ["Plusieurs millions", "Des milliers"],
    correctAnswer: "Plusieurs millions"
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://lingua.com/mp3/listening/francais-mes-animaux-de-compagnie-eK6K4yHR9cj.mp3',
    question: "D'où viennent principalement les touristes ?",
    options: ["Du Royaume-Uni", "Des États-Unis"],
    correctAnswer: "Du Royaume-Uni"
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://lingua.com/mp3/listening/francais-mes-animaux-de-compagnie-eK6K4yHR9cj.mp3',
    question: "Comment est le climat en France ?",
    options: ["Tempéré", "Tropical"],
    correctAnswer: "Tempéré"
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://lingua.com/mp3/listening/francais-mes-animaux-de-compagnie-eK6K4yHR9cj.mp3',
    question: "Quel océan ou mer ne peut-on pas trouver en France ?",
    options: ["L'océan Pacifique", "La mer Méditerranée"],
    correctAnswer: "L'océan Pacifique"
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://lingua.com/mp3/listening/francais-mes-animaux-de-compagnie-eK6K4yHR9cj.mp3',
    question: "Dans quelles régions françaises y a-t-il le moins de montagnes ?",
    options: ["En Bretagne", "Dans les Pyrénées"],
    correctAnswer: "En Bretagne"
  },
  {
    type: 'listening-comprehension',
    audioUrl: 'https://lingua.com/mp3/listening/francais-mes-animaux-de-compagnie-eK6K4yHR9cj.mp3',
    question: "Où peut-on découvrir la gastronomie française ?",
    options: ["Dans les restaurants", "Dans les cinémas"],
    correctAnswer: "Dans les restaurants"
  }
];

// Unit 2: Reading Comprehension
const UNIT_2_TEXT = `Un nouveau marché bio dans le quartier

Depuis le mois dernier, un marché bio s’est installé chaque mercredi après-midi sur la petite place du quartier. Les habitants l’attendaient depuis longtemps, car il n’existait auparavant que des supermarchés. Sur ce marché, on trouve des fruits et légumes locaux, du miel, des fromages artisanaux et même du pain fait sur place. Les producteurs viennent des villages voisins et expliquent volontiers comment ils cultivent ou fabriquent leurs produits.

L’ambiance est conviviale : les clients prennent le temps de discuter, et les enfants adorent regarder la démonstration du boulanger. De nombreux habitants disent qu’ils se sentent plus motivés à manger sainement grâce au marché. Le responsable, Madame Lefèvre, souhaite encore développer l’événement en organisant bientôt des ateliers de cuisine pour les familles. Elle espère ainsi encourager les gens à consommer plus local et à mieux comprendre ce qu’ils mangent.`;

const UNIT_2_EXERCISES: Exercise[] = [
  { type: 'reading-comprehension', contextText: UNIT_2_TEXT, question: "Quel est le sujet principal du texte ?", options: ["L’ouverture d’un marché bio.", "La fermeture d'un supermarché.", "Une fête de quartier."], correctAnswer: "L’ouverture d’un marché bio." },
  { type: 'reading-comprehension', contextText: UNIT_2_TEXT, question: "Le marché a lieu chaque mercredi matin.", options: ["Vrai", "Faux", "Non dit"], correctAnswer: "Faux" },
  { type: 'reading-comprehension', contextText: UNIT_2_TEXT, question: "On peut acheter du miel sur ce marché.", options: ["Vrai", "Faux", "Non dit"], correctAnswer: "Vrai" },
  { type: 'reading-comprehension', contextText: UNIT_2_TEXT, question: "Les producteurs viennent uniquement de la ville.", options: ["Vrai", "Faux", "Non dit"], correctAnswer: "Faux" },
  { type: 'reading-comprehension', contextText: UNIT_2_TEXT, question: "Où se trouve le marché ?", options: ["Devant le supermarché.", "Sur la petite place du quartier.", "Dans le village voisin."], correctAnswer: "Sur la petite place du quartier." },
  { type: 'reading-comprehension', contextText: UNIT_2_TEXT, question: "Qui est responsable du marché ?", options: ["Le maire.", "Le boulanger.", "Madame Lefèvre."], correctAnswer: "Madame Lefèvre." },
  { type: 'reading-comprehension', contextText: UNIT_2_TEXT, question: "Que souhaitent bientôt organiser les responsables ?", options: ["Des ateliers de cuisine.", "Des concerts.", "Des visites de fermes."], correctAnswer: "Des ateliers de cuisine." },
  { type: 'reading-comprehension', contextText: UNIT_2_TEXT, question: "Pourquoi les habitants se sentent-ils motivés à manger sainement ?", options: ["Les produits sont locaux et de qualité.", "C'est moins cher.", "Le médecin l'a conseillé."], correctAnswer: "Les produits sont locaux et de qualité." },
];

const UNIT_2_TEXT_FRANCE = `La France est un pays riche en histoire, en culture et en diversité. Chaque région a ses propres traditions, ses spécialités culinaires et ses paysages magnifiques. Paris, la capitale, est un centre mondial de la culture et de la mode. Le musée du Louvre, la Tour Eiffel et les Champs-Élysées sont quelques-uns des endroits les plus visités par les touristes du monde entier.

À l’ouest, la Bretagne est connue pour ses côtes sauvages et ses traditions celtiques. Les habitants de cette région parlent parfois breton et aiment célébrer des festivals de musique traditionnelle. Plus au sud, la Provence est célèbre pour ses champs de lavande, ses oliviers et son climat ensoleillé. C’est une région idéale pour les amateurs de nature et de randonnée.

Dans le centre de la France, on trouve des châteaux et des villages pittoresques. Le Val de Loire, par exemple, est une vallée où se trouvent certains des plus beaux châteaux du pays, comme le château de Chambord et celui de Chenonceau. Les vins de cette région sont également réputés dans le monde entier.

La diversité des régions françaises est une richesse qui attire chaque année des millions de visiteurs. Que l’on cherche la mer, la montagne, ou des villes pleines de culture et d’histoire, la France offre quelque chose pour tous les goûts.`;

const UNIT_2_EXERCISES_FRANCE: Exercise[] = [
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Quelle est la capitale de la France ?", options: ["Lyon", "Marseille", "Paris"], correctAnswer: "Paris" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Quels sont trois sites touristiques célèbres à Paris ?", options: ["Le Colisée, la Tour Eiffel, le musée du Louvre", "La Tour Eiffel, le musée du Louvre, les Champs-Élysées", "Notre-Dame, la Tour Montparnasse, le musée d'Orsay"], correctAnswer: "La Tour Eiffel, le musée du Louvre, les Champs-Élysées" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Qu’est-ce qui caractérise la région de la Bretagne ?", options: ["Des plages tropicales et des châteaux médiévaux", "Des côtes sauvages et des traditions celtiques", "Des champs de lavande et un climat ensoleillé"], correctAnswer: "Des côtes sauvages et des traditions celtiques" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Que parlent certains habitants de la Bretagne ?", options: ["Breton", "Alsacien", "Provençal"], correctAnswer: "Breton" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Quel est le climat typique de la Provence ?", options: ["Climat froid et pluvieux", "Climat tempéré et humide", "Climat ensoleillé"], correctAnswer: "Climat ensoleillé" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Pourquoi la Provence est-elle populaire auprès des amateurs de nature ?", options: ["Pour ses montagnes et ses forêts", "Pour ses champs de lavande et ses oliviers", "Pour ses stations de ski"], correctAnswer: "Pour ses champs de lavande et ses oliviers" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Où se trouvent les châteaux du Val de Loire ?", options: ["Dans le sud de la France", "Dans le centre de la France", "En Bretagne"], correctAnswer: "Dans le centre de la France" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Nomme deux châteaux célèbres du Val de Loire.", options: ["Château de Versailles et château de Fontainebleau", "Château de Chambord et château de Chenonceau", "Château de Carcassonne et château de Nice"], correctAnswer: "Château de Chambord et château de Chenonceau" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Quels types de paysages peut-on trouver en France ?", options: ["Des plages de sable blanc et des dunes", "Des montagnes, des plages, des forêts, des champs", "Des déserts et des canyons"], correctAnswer: "Des montagnes, des plages, des forêts, des champs" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Quelles spécialités la région de la Bretagne est-elle connue pour ?", options: ["Le fromage de chèvre", "Les crêpes et le cidre", "La soupe de poisson"], correctAnswer: "Les crêpes et le cidre" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Pourquoi la France est-elle un pays riche ?", options: ["À cause de son économie florissante et de ses traditions culturelles", "À cause de ses mines d'or", "Grâce à ses inventions scientifiques"], correctAnswer: "À cause de son économie florissante et de ses traditions culturelles" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Quel est le rôle de Paris dans le monde ?", options: ["C'est une capitale politique et militaire", "C'est un centre mondial de la culture et de la mode", "C'est la capitale de l'industrie"], correctAnswer: "C'est un centre mondial de la culture et de la mode" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Que représente la Tour Eiffel pour la France ?", options: ["Un site historique important", "Un symbole national de la France", "Un bâtiment administratif"], correctAnswer: "Un symbole national de la France" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Quels types de touristes visitent la France chaque année ?", options: ["Des amateurs de nature uniquement", "Des amateurs de culture et d'histoire, ainsi que des vacanciers", "Des touristes uniquement intéressés par le shopping"], correctAnswer: "Des amateurs de culture et d'histoire, ainsi que des vacanciers" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Pourquoi la région de la Provence est-elle ensoleillée ?", options: ["À cause de sa proximité avec la mer Méditerranée", "Parce qu'elle est située dans une vallée montagneuse", "À cause de la chaleur des volcans locaux"], correctAnswer: "À cause de sa proximité avec la mer Méditerranée" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Qu’est-ce qui rend les vins du Val de Loire célèbres ?", options: ["Leur production en grande quantité", "Leur qualité et leur renommée mondiale", "Leur couleur unique"], correctAnswer: "Leur qualité et leur renommée mondiale" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Que peuvent faire les visiteurs qui aiment l’histoire en France ?", options: ["Visiter des châteaux, des musées et des monuments historiques", "Faire du shopping dans des centres commerciaux", "Partir à la recherche de fossiles"], correctAnswer: "Visiter des châteaux, des musées et des monuments historiques" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Quel est l’intérêt des festivals de musique traditionnelle en Bretagne ?", options: ["Ils permettent de découvrir des instruments modernes", "Ils célèbrent la culture celte et les traditions locales", "Ils sont dédiés à la danse contemporaine"], correctAnswer: "Ils célèbrent la culture celte et les traditions locales" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Qu’est-ce que la France a à offrir pour les amateurs de randonnée ?", options: ["Des plages pour le surf", "Des montagnes et des paysages variés pour la randonnée", "Des pistes de ski uniquement"], correctAnswer: "Des montagnes et des paysages variés pour la randonnée" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_FRANCE, question: "Pourquoi la France est-elle une destination touristique très appréciée ?", options: ["Pour ses plages de sable fin et ses stations balnéaires", "Pour sa diversité culturelle, ses paysages et son histoire", "Pour son climat tropical"], correctAnswer: "Pour sa diversité culturelle, ses paysages et son histoire" },
];

const UNIT_2_TEXT_SMOKING = `Journaliste : Aujourd’hui, nous interrogeons plusieurs personnes sur leur relation avec la cigarette.

Journaliste : Julie, pourquoi avez-vous arrêté de fumer ?
Julie : J’ai arrêté il y a six mois. Je fumais surtout en soirée, mais je me suis rendu compte que je devenais dépendante. Maintenant, je respire mieux.

Journaliste : Karim, que représente la cigarette pour vous ?
Karim : Je fume environ un paquet par jour. Pour moi, c’est une façon de gérer le stress, même si je sais que ce n’est pas bon pour ma santé.

Journaliste : Élise, vous n’avez jamais fumé. Pourquoi ?
Élise : L’odeur du tabac me dérange beaucoup. Et je pense que la cigarette est dangereuse aussi pour les personnes autour, pas seulement pour les fumeurs.

Journaliste : Marc, vous avez tenté d’arrêter plusieurs fois. Qu’est-ce qui vous empêche de réussir ?
Marc : La tentation. Dès que je suis avec des amis qui fument, j’ai envie de reprendre. Les patchs m’aident, mais ce n’est pas facile.

Journaliste : Clara, vous avez fumé pendant longtemps. Comment voyez-vous la cigarette aujourd’hui ?
Clara : J’ai fumé plus de trente ans. J’ai arrêté après un problème de santé. Aujourd’hui, je regrette beaucoup d’avoir commencé.

Ces entretiens montrent que la cigarette provoque des expériences très différentes selon chacun.`;

const UNIT_2_EXERCISES_SMOKING: Exercise[] = [
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Qui a arrêté il y a six mois ?", options: ["Julie", "Élise"], correctAnswer: "Julie" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Pourquoi Julie fumait-elle ?", options: ["En soirée", "Au travail"], correctAnswer: "En soirée" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Comment se sent Julie maintenant ?", options: ["Elle respire mieux", "Elle est plus stressée"], correctAnswer: "Elle respire mieux" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Combien fume Karim ?", options: ["Un paquet par jour", "Deux cigarettes par semaine"], correctAnswer: "Un paquet par jour" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Pourquoi Karim fume-t-il ?", options: ["Pour le stress", "Pour le goût"], correctAnswer: "Pour le stress" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Que pense Élise de l’odeur du tabac ?", options: ["Elle l’aime bien", "Elle la trouve désagréable"], correctAnswer: "Elle la trouve désagréable" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Que pense Élise des dangers ?", options: ["Ils concernent tout le monde", "Seulement les fumeurs"], correctAnswer: "Ils concernent tout le monde" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Que gêne Élise ?", options: ["Le bruit", "L’odeur du tabac"], correctAnswer: "L’odeur du tabac" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Qui utilise parfois des patchs ?", options: ["Marc", "Karim"], correctAnswer: "Marc" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Pourquoi Marc rechute-t-il ?", options: ["À cause des amis fumeurs", "Par manque d’argent"], correctAnswer: "À cause des amis fumeurs" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Qui a fumé 30 ans ?", options: ["Clara", "Julie"], correctAnswer: "Clara" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Pourquoi Clara a-t-elle arrêté ?", options: ["Problème de santé", "Par ennui"], correctAnswer: "Problème de santé" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Que ressent Clara aujourd’hui ?", options: ["De la satisfaction", "Du regret"], correctAnswer: "Du regret" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Qui n’a jamais fumé ?", options: ["Élise", "Marc"], correctAnswer: "Élise" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Pourquoi Élise ne fume-t-elle pas ?", options: ["Elle est sportive", "Elle déteste l’odeur"], correctAnswer: "Elle déteste l’odeur" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Qui parle de dépendance ?", options: ["Julie", "Karim"], correctAnswer: "Julie" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Qui fume à cause du stress ?", options: ["Karim", "Élise"], correctAnswer: "Karim" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Qui se sent mieux après avoir arrêté ?", options: ["Julie", "Marc"], correctAnswer: "Julie" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Qui a le plus de difficultés à arrêter ?", options: ["Marc", "Julie"], correctAnswer: "Marc" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_SMOKING, question: "Que montrent les entretiens ?", options: ["Des avis variés sur la cigarette", "Que tout le monde fume"], correctAnswer: "Des avis variés sur la cigarette" },
];

const UNIT_2_TEXT_CHARLIE = `Charlie était assis seul sur un banc, dans un petit parc calme. La journée était grise, et les feuilles tombaient lentement autour de lui. Il regardait le sol, l’air fatigué et profondément triste. Depuis plusieurs jours, il n’arrivait plus à se concentrer ni à trouver de motivation. Il venait de perdre son emploi, et cette nouvelle l’avait complètement découragé.

Alors qu’il soupirait, une femme s’approcha doucement. Elle marchait lentement, comme si elle hésitait à le déranger. Finalement, elle s’assit à l’autre bout du banc. Après quelques secondes de silence, elle tourna la tête vers lui et dit doucement :

— Excusez-moi… Vous allez bien ? Vous semblez préoccupé.

Charlie leva les yeux, surpris. Il ne s’attendait pas à ce que quelqu’un lui parle. Il répondit d’une voix faible :

— Pas vraiment… J’ai perdu mon travail cette semaine, et je ne sais pas quoi faire.

La femme hocha la tête avec compréhension.

— Je suis désolée. C’est une situation difficile, mais vous n’êtes pas seul. Parfois, parler peut vraiment aider à se sentir mieux.

Charlie n’avait pas l’habitude de se confier à des inconnus, mais il sentait que cette femme était sincère. Il expliqua son inquiétude, sa peur du futur et sa perte de confiance. Elle l’écouta sans l’interrompre, avec une attention douce et patiente.

À la fin de leur conversation, Charlie se sentit un peu plus léger. La femme se leva et lui dit :

— Courage. Les choses changent toujours, même quand on ne s’y attend pas.

Charlie la remercia. Pour la première fois depuis longtemps, il sentit un petit espoir renaître.`;

const UNIT_2_EXERCISES_CHARLIE: Exercise[] = [
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Où est assis Charlie ?", options: ["Dans un café", "Sur un banc"], correctAnswer: "Sur un banc" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Comment est la journée ?", options: ["Ensoleillée", "Grise"], correctAnswer: "Grise" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Comment se sent Charlie ?", options: ["Joyeux", "Triste"], correctAnswer: "Triste" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Pourquoi est-il découragé ?", options: ["Il a perdu son emploi", "Il a perdu son téléphone"], correctAnswer: "Il a perdu son emploi" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Que fait la femme ?", options: ["Elle passe sans s’arrêter", "Elle s’assoit près de lui"], correctAnswer: "Elle s’assoit près de lui" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Pourquoi hésite-t-elle ?", options: ["Elle ne veut pas le déranger", "Elle est pressée"], correctAnswer: "Elle ne veut pas le déranger" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Que demande la femme à Charlie ?", options: ["Si elle peut fumer", "S’il va bien"], correctAnswer: "S’il va bien" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Comment Charlie réagit-il ?", options: ["Il reste silencieux", "Il répond faiblement"], correctAnswer: "Il répond faiblement" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "De quoi parle-t-il ?", options: ["De son travail perdu", "De ses vacances"], correctAnswer: "De son travail perdu" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Comment la femme réagit-elle ?", options: ["Avec compréhension", "Avec colère"], correctAnswer: "Avec compréhension" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Que conseille-t-elle ?", options: ["De partir en voyage", "De parler pour se sentir mieux"], correctAnswer: "De parler pour se sentir mieux" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Charlie se confie-t-il facilement ?", options: ["Non", "Oui"], correctAnswer: "Non" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Pourquoi se confie-t-il finalement ?", options: ["Il sent qu’elle est sincère", "Il veut lui demander de l’argent"], correctAnswer: "Il sent qu’elle est sincère" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Comment la femme l’écoute-t-elle ?", options: ["Avec impatience", "Sans l’interrompre"], correctAnswer: "Sans l’interrompre" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Qu’éprouve Charlie après avoir parlé ?", options: ["De la colère", "Un peu de légèreté"], correctAnswer: "Un peu de légèreté" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Que dit la femme en partant ?", options: ["D’abandonner", "D’avoir du courage"], correctAnswer: "D’avoir du courage" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Que ressent Charlie à la fin ?", options: ["De l’espoir", "Plus de tristesse"], correctAnswer: "De l’espoir" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Que tombait autour du banc ?", options: ["Des feuilles", "De la neige"], correctAnswer: "Des feuilles" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Depuis combien de jours Charlie va-t-il mal ?", options: ["Depuis quelques jours", "Depuis des années"], correctAnswer: "Depuis quelques jours" },
    { type: 'reading-comprehension', contextText: UNIT_2_TEXT_CHARLIE, question: "Quel est le message principal du texte ?", options: ["Parler peut aider à aller mieux", "Il faut toujours rester seul"], correctAnswer: "Parler peut aider à aller mieux" },
];

// --- UNIT 3: WRITING CONTENT ---

const WRITING_TOPICS = [
    {
        title: "Opinion",
        prompt: `Votre ville veut fermer un parc public pour construire un parking.
Écrivez une lettre ou un e-mail au maire pour :
- Expliquer votre point de vue
- Donner des arguments pour ou contre la décision
- Proposer éventuellement une solution alternative

(B2 : utilisez des connecteurs logiques et des phrases plus longues pour argumenter)`
    },
    {
        title: "Réclamation",
        prompt: `Vous avez acheté un produit en ligne, mais il est arrivé cassé ou en retard.
Écrivez un message ou une lettre au service client pour :
- Expliquer le problème
- Demander un remboursement, un échange ou une solution
- Rester poli et clair

(B2 : utilisez un ton plus formel et introduisez des phrases conditionnelles ou hypothétiques)`
    },
    {
        title: "Souvenir",
        prompt: `Racontez une situation où vous avez aidé quelqu’un ou participé à une activité importante :
- Décrivez le contexte
- Expliquez vos actions
- Partagez vos sentiments ou les réactions des autres

(B2 : ajoutez des détails, des descriptions, et utilisez le passé composé et l’imparfait pour nuancer)`
    },
    {
        title: "Infos",
        prompt: `Vous voulez vous inscrire à un cours, un club ou un événement.
Écrivez un e-mail pour demander :
- Les horaires, le prix, la durée
- Les documents ou conditions nécessaires
- Toutes autres informations utiles

(B2 : utilisez des formules de politesse et des phrases plus complexes pour rendre la demande plus professionnelle)`
    },
    {
        title: "Société",
        prompt: `Les réseaux sociaux peuvent être utiles mais parfois dangereux.
Écrivez un texte pour :
- Donner votre opinion
- Décrire les avantages et les inconvénients
- Donner des exemples pour soutenir vos arguments

(B2 : structurez votre texte avec introduction, développement et conclusion, utilisez des connecteurs et le vocabulaire nuancé)`
    },
    {
        title: "Projet",
        prompt: `Vous souhaitez organiser une sortie culturelle ou un événement avec vos amis ou votre famille :
- Expliquez le lieu, la date et le programme
- Décrivez les raisons de votre choix
- Indiquez ce que chacun doit apporter ou préparer

(B2 : détaillez davantage, utilisez le futur et le conditionnel pour présenter les options ou suggestions)`
    },
    {
        title: "Décision",
        prompt: `Vous devez informer votre employeur ou un responsable que vous changez d’horaires ou ne pouvez plus participer à une activité :
- Expliquez clairement la situation
- Proposez une solution alternative
- Restez poli et professionnel

(B2 : utilisez des formulations plus élaborées et polies, par ex. « Je vous serais reconnaissant(e) si… »)`
    },
    {
        title: "Conseil",
        prompt: `Un ami veut apprendre le français ou préparer un examen comme le TEF.
Écrivez un texte pour :
- Expliquer ce qu’il doit faire
- Donner des conseils pratiques et utiles
- Motiver votre ami

(B2 : utilisez des phrases conditionnelles et des adverbes pour nuancer vos recommandations)`
    }
];

// --- UNIT 5: UNDERSTAND A CONVERSATION ---

const UNIT_5_DIALOGUE_1 = `Serveur : Bonjour, je peux prendre votre commande ?
Client : Bonjour. Oui, je vais prendre le menu du jour, s'il vous plaît.
Serveur : Très bien. En entrée, vous avez le choix entre une salade de chèvre chaud ou une soupe à l'oignon.
Client : Je vais prendre la salade.
Serveur : Et pour le plat principal ? Aujourd'hui, c'est poulet rôti ou poisson grillé.
Client : Le poulet, s'il vous plaît. Avec des frites ?
Serveur : Non, c'est servi avec des haricots verts aujourd'hui.
Client : D'accord, parfait. Et une carafe d'eau, merci.`;

const UNIT_5_EXERCISES_1: Exercise[] = [
    { type: 'reading-comprehension', contextText: UNIT_5_DIALOGUE_1, question: "Que commande le client en entrée ?", options: ["Une soupe à l'oignon", "Une salade de chèvre chaud"], correctAnswer: "Une salade de chèvre chaud" },
    { type: 'reading-comprehension', contextText: UNIT_5_DIALOGUE_1, question: "Quel est le plat principal choisi ?", options: ["Poisson grillé", "Poulet rôti"], correctAnswer: "Poulet rôti" },
    { type: 'reading-comprehension', contextText: UNIT_5_DIALOGUE_1, question: "Avec quoi le poulet est-il servi ?", options: ["Des frites", "Des haricots verts"], correctAnswer: "Des haricots verts" },
    { type: 'reading-comprehension', contextText: UNIT_5_DIALOGUE_1, question: "Que boit le client ?", options: ["Du vin", "De l'eau"], correctAnswer: "De l'eau" },
];

const UNIT_5_DIALOGUE_2 = `Sophie : Salut Marc, tu as fait quoi ce week-end ?
Marc : Salut ! Samedi, je suis allé au cinéma voir le nouveau film d'action. C'était génial.
Sophie : Ah oui ? Moi je n'aime pas trop les films d'action, je préfère les comédies. Et dimanche ?
Marc : Dimanche, il pleuvait, alors je suis resté chez moi à lire. Et toi ?
Sophie : J'ai rendu visite à mes grands-parents à la campagne. Il faisait beau là-bas.
Marc : Tu as de la chance !`;

const UNIT_5_EXERCISES_2: Exercise[] = [
    { type: 'reading-comprehension', contextText: UNIT_5_DIALOGUE_2, question: "Que fait Marc samedi ?", options: ["Il va au cinéma", "Il lit chez lui"], correctAnswer: "Il va au cinéma" },
    { type: 'reading-comprehension', contextText: UNIT_5_DIALOGUE_2, question: "Quel genre de film Sophie préfère-t-elle ?", options: ["Action", "Comédie"], correctAnswer: "Comédie" },
    { type: 'reading-comprehension', contextText: UNIT_5_DIALOGUE_2, question: "Quel temps faisait-il chez Marc dimanche ?", options: ["Il pleuvait", "Il y avait du soleil"], correctAnswer: "Il pleuvait" },
    { type: 'reading-comprehension', contextText: UNIT_5_DIALOGUE_2, question: "Où était Sophie dimanche ?", options: ["Au cinéma", "À la campagne"], correctAnswer: "À la campagne" },
];

// --- UNIT 6: GIVE YOUR OPINION (THE DOG SPEAKS) - VARIED LESSONS ---

// Helper function to create dog format
const d = (s: string, c: string, o: string[]) => ({
    type: 'select-meaning' as const,
    question: `Le Chien affirme : « ${s} » \nQue répondez-vous ?`,
    options: [c, ...o].sort(() => Math.random() - 0.5),
    correctAnswer: c
});

const UNIT_6_LESSON_1: Exercise[] = [ // Introduction
    d("Personne ne m'aime.", "Mais si, je t'aime bien !", ["C'est vrai.", "Pauvre chien."]),
    d("L'argent ne fait pas le bonheur, mais les os oui.", "L'argent aide quand même.", ["Les os sont délicieux.", "Je suis d'accord avec toi."]),
    d("Je suis le roi de la maison.", "Non, tu es un chien.", ["Oui votre majesté.", "C'est le chat le roi."]),
    d("Pourquoi tu pars travailler ?", "Pour acheter tes croquettes.", ["Parce que je ne t'aime pas.", "Pour dormir au bureau."])
];

const UNIT_6_LESSON_2: Exercise[] = [ // Ennemis (Chats, Ecureuils)
    d("Les chats sont des créatures inutiles et sournoises.", "Je ne suis pas d'accord, ils sont indépendants.", ["C'est vrai, ils sont méchants.", "Je préfère les poissons."]),
    d("Les écureuils complotent contre nous.", "Tu es paranoïaque.", ["Je les surveille aussi.", "Les écureuils sont mignons."]),
    d("Le chat du voisin m'a regardé bizarrement.", "Il t'a juste ignoré.", ["Attaque-le !", "Il veut jouer."]),
    d("Je dois aboyer sur les oiseaux.", "Laisse-les tranquilles.", ["Vole avec eux.", "Mange-les."])
];

const UNIT_6_LESSON_3: Exercise[] = [ // Hygiène & Pluie
    d("Il ne faut jamais se laver, l'odeur naturelle est meilleure.", "L'hygiène est importante.", ["Tu as raison, le savon pue.", "Je me lave tous les jours."]),
    d("La pluie, c'est nul, on est tout mouillé.", "C'est bon pour la nature.", ["Je déteste la pluie.", "J'aime sauter dans les flaques."]),
    d("J'aime me rouler dans la boue.", "Tu vas devoir prendre un bain.", ["C'est bon pour la peau.", "Quelle horreur."]),
    d("Le bain est un instrument de torture.", "C'est pour ton bien.", ["Appelle la police.", "L'eau est chaude pourtant."])
];

const UNIT_6_LESSON_4: Exercise[] = [ // Nourriture
    d("Il faut manger de la pizza tous les jours pour être heureux.", "C'est mauvais pour la santé.", ["Oui, c'est mon plat préféré.", "Je déteste la pizza."]),
    d("Voler de la nourriture sur la table est un art.", "C'est mal élevé.", ["J'ai faim aussi.", "Tu es un artiste."]),
    d("Je veux goûter ton chocolat.", "C'est toxique pour les chiens !", ["Tiens, prends un morceau.", "C'est trop sucré."]),
    d("Les croquettes, c'est ennuyeux.", "C'est équilibré pour toi.", ["Mange de la salade.", "Je vais cuisiner pour toi."])
];

const UNIT_6_LESSON_5: Exercise[] = [ // Humains & Objets
    d("Les humains devraient marcher à quatre pattes.", "Ce n'est pas naturel pour nous.", ["Pourquoi pas essayer ?", "C'est une idée ridicule."]),
    d("Le facteur est notre ennemi juré.", "Il fait juste son travail.", ["Attaquons-le !", "Je n'aime pas le courrier."]),
    d("On devrait interdire les aspirateurs, ils font trop de bruit.", "Ils sont utiles pour le ménage.", ["Oui, j'ai peur du bruit.", "Le silence est d'or."]),
    d("Pourquoi tu regardes cette boîte lumineuse (TV) ?", "C'est un film.", ["C'est une fenêtre.", "Je ne sais pas."])
];

const UNIT_6_LESSON_6: Exercise[] = [ // Activités de chien
    d("Dormir 20 heures par jour est la clé du succès.", "C'est beaucoup trop !", ["Je suis d'accord, je suis fatigué.", "Le travail est plus important."]),
    d("Courir après les voitures est un sport olympique.", "C'est très dangereux !", ["J'adore courir aussi.", "Ce n'est pas un sport."]),
    d("Il faut aboyer quand on est content.", "Les humains crient ou rient.", ["Wouaf !", "Le silence est mieux."]),
    d("Je veux creuser un trou dans le canapé.", "Absolument pas !", ["Bonne idée.", "Cherche un trésor."])
];

const UNIT_6_LESSON_7: Exercise[] = [ // Mix / Bilan
    d("Je suis un bon chien ?", "Oui, tu es le meilleur.", ["Non, tu es vilain.", "Peut-être."]),
    d("Les chats sont nuls.", "Arrête avec les chats.", ["Oui !", "J'aime les chats."]),
    d("Donne-moi ton sandwich.", "Non, c'est mon déjeuner.", ["D'accord.", "Prends-le."]),
    d("Je t'aime.", "Moi aussi mon chien.", ["Pff.", "Laisse-moi."])
];


// --- UNIT 7: DIRE CE QU'ON AIME (LISA) - VARIED LESSONS ---

// Helper for Lisa
const l = (q: string, c: string, o: string[]) => ({
    type: 'select-meaning' as const,
    question: `Lisa : ${q}`,
    options: [c, ...o].sort(() => Math.random() - 0.5),
    correctAnswer: c
});

const UNIT_7_LESSON_1: Exercise[] = [ // Rencontre / Bases
    l("Bonjour ! Tu aimes le sport ?", "Oui, j’aime beaucoup le sport.", ["Non, je déteste manger.", "Je préfère le chocolat."]),
    l("Super ! Et tu aimes le cinéma ?", "Oui, j’adore aller au cinéma.", ["Je n’aime pas la musique.", "Je déteste les couleurs."]),
    l("Et la musique, tu aimes ?", "Oui, j’aime la musique.", ["Je préfère le lundi.", "Je n’aime pas ma chaise."]),
    l("Dernière question : qu’est-ce que tu préfères ?", "Je préfère le sport.", ["Je préfère marcher à côté.", "Je préfère demain."])
];

const UNIT_7_LESSON_2: Exercise[] = [ // Loisirs & Culture
    l("Est-ce que tu aimes lire des livres ?", "J'adore lire des romans.", ["Je n'aime pas nager.", "Le livre est bleu."]),
    l("Tu aimes voyager ?", "Oui, surtout en été.", ["Je préfère rester debout.", "Non, je mange."]),
    l("Tu préfères les jeux vidéo ou le sport ?", "Je préfère le sport.", ["Je préfère dormir.", "Le jeu est rouge."]),
    l("Tu aimes aller au musée ?", "Oui, c'est très intéressant.", ["Non, je suis une pomme.", "Le musée est fermé."])
];

const UNIT_7_LESSON_3: Exercise[] = [ // Nourriture
    l("Tu aimes la cuisine italienne ?", "Oui, j'adore la pizza et les pâtes.", ["Non, je suis fatigué.", "La cuisine est une pièce."]),
    l("Est-ce que tu aimes les légumes ?", "Ça dépend, j'aime les carottes.", ["Je préfère le plastique.", "Les légumes sont bleus."]),
    l("Tu préfères le café ou le thé ?", "Je préfère le thé.", ["Je préfère le sable.", "Le café est froid."]),
    l("Tu aimes cuisiner ?", "Non, je ne sais pas cuisiner.", ["Oui, je conduis bien.", "La cuisine est grande."])
];

const UNIT_7_LESSON_4: Exercise[] = [ // Travail & École
    l("Tu aimes ton travail ?", "Oui, c'est passionnant.", ["Non, je mange une pomme.", "Le travail est gris."]),
    l("Tu préférais l'école ou le lycée ?", "Je préférais le lycée.", ["Je préférais le dîner.", "L'école est loin."]),
    l("Tu aimes les mathématiques ?", "Non, je déteste les maths.", ["Oui, j'aime courir.", "Les maths sont vertes."]),
    l("Qu'est-ce que tu aimes faire le week-end ?", "J'aime me reposer.", ["J'aime travailler le lundi.", "Le week-end est court."])
];

// --- UNIT 8: DEMANDER DE L'AIDE ---

const CHAR_DOG = "https://postimg.cc/mPt54zLd";
const CHAR_CAT = "https://i.postimg.cc/8P3McSdW/1m.png";

// Helper to generate Unit 8 exercises with random images and repeat to hit 15
const generateUnit8Exercises = (baseExercises: Exercise[]): Exercise[] => {
    let result: Exercise[] = [];
    // Repeat the base exercises enough times to fill 15 slots, shuffling a bit
    while (result.length < 15) {
        for (const ex of baseExercises) {
            if (result.length >= 15) break;
            const isDog = Math.random() > 0.5;
            result.push({
                ...ex,
                characterImage: isDog ? CHAR_DOG : CHAR_CAT,
                options: [...(ex.options || [])].sort(() => Math.random() - 0.5)
            });
        }
    }
    return result;
};

// Lesson 1: Politeness (Conditionnel vs Présent) - Fill Gap focus
const U8_L1_BASE: Exercise[] = [
    { type: 'fill-gap', question: "Je ____ (vouloir) un verre d'eau, s'il vous plaît.", options: ["voudrais", "veux", "voulais"], correctAnswer: "voudrais" },
    { type: 'fill-gap', question: "Est-ce que je ____ (pouvoir) avoir l'addition ?", options: ["pourrais", "peux", "pouvais"], correctAnswer: "pourrais" },
    { type: 'fill-gap', question: "Tu ____ (pouvoir) m'aider ?", options: ["pourrais", "peux", "pourrai"], correctAnswer: "pourrais" },
    { type: 'fill-gap', question: "Nous ____ (aimer) réserver une table.", options: ["aimerions", "aimons", "aimerons"], correctAnswer: "aimerions" },
    { type: 'select-meaning', question: "Bonjour, je voudrais une baguette.", options: ["Voici, ça fera 1 euro.", "Non, au revoir.", "Je ne sais pas."], correctAnswer: "Voici, ça fera 1 euro." },
];

// Lesson 2: Asking directions / help
const U8_L2_BASE: Exercise[] = [
    { type: 'fill-gap', question: "Excusez-moi, où ____ (être) la gare ?", options: ["est", "suis", "es"], correctAnswer: "est" },
    { type: 'fill-gap', question: "Je ____ (chercher) la pharmacie.", options: ["cherche", "cherches", "chercher"], correctAnswer: "cherche" },
    { type: 'select-meaning', question: "Pouvez-vous m'aider, s'il vous plaît ?", options: ["Oui, bien sûr.", "Non, je dors.", "Je suis une pomme."], correctAnswer: "Oui, bien sûr." },
    { type: 'select-meaning', question: "C'est loin d'ici ?", options: ["Non, c'est tout près.", "Oui, c'est bleu.", "Je mange ici."], correctAnswer: "Non, c'est tout près." },
    { type: 'fill-gap', question: "Pour aller au musée, vous ____ (devoir) tourner à gauche.", options: ["devez", "dois", "devons"], correctAnswer: "devez" },
];

// Lesson 3: Situations (Store/Restaurant)
const U8_L3_BASE: Exercise[] = [
    { type: 'fill-gap', question: "Vous ____ (avoir) des stylos rouges ?", options: ["avez", "ont", "avons"], correctAnswer: "avez" },
    { type: 'fill-gap', question: "Combien ça ____ (coûter) ?", options: ["coûte", "coûtent", "coûtes"], correctAnswer: "coûte" },
    { type: 'select-meaning', question: "Je peux payer par carte ?", options: ["Oui, sans problème.", "Non, seulement en bananes.", "Le ciel est bleu."], correctAnswer: "Oui, sans problème." },
    { type: 'fill-gap', question: "Je ____ (prendre) le menu à 15 euros.", options: ["prends", "prend", "prenons"], correctAnswer: "prends" },
    { type: 'select-meaning', question: "Avez-vous choisi ?", options: ["Oui, je vais prendre le poulet.", "Non, je pars.", "Je suis fatigué."], correctAnswer: "Oui, je vais prendre le poulet." },
];

// Lesson 4: Review / Challenge
const U8_L4_BASE: Exercise[] = [
    { type: 'fill-gap', question: "S'il vous plaît, je ____ (vouloir) sortir.", options: ["voudrais", "veux", "voulais"], correctAnswer: "voudrais" },
    { type: 'fill-gap', question: "Pardon, je ne ____ (comprendre) pas.", options: ["comprends", "comprendre", "compris"], correctAnswer: "comprends" },
    { type: 'select-meaning', question: "Pourriez-vous répéter ?", options: ["D'accord, je répète.", "Non, jamais.", "Il pleut."], correctAnswer: "D'accord, je répète." },
    { type: 'fill-gap', question: "Est-ce que vous ____ (parler) anglais ?", options: ["parlez", "parle", "parlent"], correctAnswer: "parlez" },
    { type: 'select-meaning', question: "Au secours ! J'ai besoin d'aide.", options: ["J'arrive tout de suite !", "Bonjour, ça va ?", "Je mange une glace."], correctAnswer: "J'arrive tout de suite !" },
];

// --- UNIT 9: PARLER À SES AMIS ---

// Helper to ensure 17 exercises per lesson for Unit 9
const generateUnit9Content = (base: Exercise[]): Exercise[] => {
    let result: Exercise[] = [];
    while (result.length < 17) {
        for (const ex of base) {
            if (result.length >= 17) break;
            result.push({
                ...ex,
                options: ex.options ? [...ex.options].sort(() => Math.random() - 0.5) : undefined
            });
        }
    }
    return result;
};

// Lesson 1: Présentation
const U9_L1_BASE: Exercise[] = [
    { type: 'select-meaning', question: "Salut ! Comment tu t'appelles ?", options: ["Je m'appelle Thomas.", "J'ai faim.", "Il est midi."], correctAnswer: "Je m'appelle Thomas." },
    { type: 'fill-gap', question: "Voici mon ami, il ____ (s'appeler) Pierre.", options: ["s'appelle", "t'appelles", "m'appelle"], correctAnswer: "s'appelle" },
    { type: 'fill-gap', question: "Tu ____ (avoir) quel âge ?", options: ["as", "a", "avez"], correctAnswer: "as" },
    { type: 'select-meaning', question: "Enchanté de faire ta connaissance.", options: ["Moi aussi !", "Non merci.", "Au revoir."], correctAnswer: "Moi aussi !" },
    { type: 'fill-gap', question: "J'____ (habiter) à Paris.", options: ["habite", "habites", "habiter"], correctAnswer: "habite" },
];

// Lesson 2: Parler de ses opinions
const U9_L2_BASE: Exercise[] = [
    { type: 'select-meaning', question: "Qu'est-ce que tu penses de ce livre ?", options: ["Je le trouve génial.", "Je mange une pomme.", "Il est bleu."], correctAnswer: "Je le trouve génial." },
    { type: 'fill-gap', question: "À mon ____ (avis), c'est une mauvaise idée.", options: ["avis", "idée", "pensée"], correctAnswer: "avis" },
    { type: 'select-meaning', question: "Je ne suis pas d'accord avec toi.", options: ["Pourquoi ?", "Merci.", "Bonjour."], correctAnswer: "Pourquoi ?" },
    { type: 'fill-gap', question: "Je ____ (penser) que c'est important.", options: ["pense", "penses", "pensons"], correctAnswer: "pense" },
    { type: 'select-meaning', question: "C'est nul !", options: ["Tu es difficile.", "C'est délicieux.", "J'adore."], correctAnswer: "Tu es difficile." },
];

// Lesson 3: Sortie au cinéma
const U9_L3_BASE: Exercise[] = [
    { type: 'select-meaning', question: "Tu veux aller au cinéma ce soir ?", options: ["Oui, bonne idée !", "Non, je vais nager.", "Le cinéma est fermé."], correctAnswer: "Oui, bonne idée !" },
    { type: 'fill-gap', question: "On regarde quel ____ (film) ?", options: ["film", "livre", "musique"], correctAnswer: "film" },
    { type: 'select-meaning', question: "Je préfère les comédies.", options: ["Moi aussi, c'est drôle.", "Je déteste rire.", "Le film est triste."], correctAnswer: "Moi aussi, c'est drôle." },
    { type: 'fill-gap', question: "La séance est à 20 ____ (heure).", options: ["heures", "minutes", "temps"], correctAnswer: "heures" },
    { type: 'select-meaning', question: "Tu veux du pop-corn ?", options: ["Oui, sucré s'il te plaît.", "Non, je veux dormir.", "Le pop-corn est rouge."], correctAnswer: "Oui, sucré s'il te plaît." },
];

// Lesson 4: Communiquer en voyage
const U9_L4_BASE: Exercise[] = [
    { type: 'fill-gap', question: "Excusez-moi, je cherche l'____ (hôtel).", options: ["hôtel", "maison", "école"], correctAnswer: "hôtel" },
    { type: 'select-meaning', question: "C'est loin de la gare ?", options: ["Non, c'est à 5 minutes.", "Oui, c'est un chat.", "Je ne sais pas nager."], correctAnswer: "Non, c'est à 5 minutes." },
    { type: 'fill-gap', question: "Je voudrais acheter un billet de ____ (train).", options: ["train", "voiture", "vélo"], correctAnswer: "train" },
    { type: 'select-meaning', question: "Avez-vous une valise ?", options: ["Oui, elle est ici.", "Non, je suis fatigué.", "La valise est bleue."], correctAnswer: "Oui, elle est ici." },
    { type: 'fill-gap', question: "Je ne trouve pas mon ____ (passeport).", options: ["passeport", "livre", "stylo"], correctAnswer: "passeport" },
];

// Lesson 5: Bilan
const U9_L5_BASE: Exercise[] = [
    { type: 'select-meaning', question: "C'était super de te voir !", options: ["À bientôt !", "Non merci.", "Je suis parti."], correctAnswer: "À bientôt !" },
    { type: 'fill-gap', question: "Tu ____ (venir) demain ?", options: ["viens", "vient", "venez"], correctAnswer: "viens" },
    { type: 'select-meaning', question: "Ce film était incroyable.", options: ["Oui, j'ai adoré.", "Non, c'est une pizza.", "Je dors."], correctAnswer: "Oui, j'ai adoré." },
    { type: 'fill-gap', question: "Je ____ (croire) que tu as raison.", options: ["crois", "croit", "croyons"], correctAnswer: "crois" },
    { type: 'select-meaning', question: "Bon voyage !", options: ["Merci beaucoup !", "Bonjour.", "Il pleut."], correctAnswer: "Merci beaucoup !" },
];

// --- UNIT 10: ENQUÊTER ET RAISONNER (DETECTIVE MYSTERY) ---

const UNIT_10_TEXT = `Qui a coupé l’électricité de la ville ?

À vingt-deux heures précises, la ville de Clairval a été soudainement plongée dans l’obscurité totale. Les feux de circulation se sont arrêtés, les hôpitaux ont activé leurs générateurs d’urgence et les habitants ont envahi les rues, inquiets. Très vite, les autorités ont compris qu’il ne s’agissait pas d’une simple panne : le câble principal de la centrale électrique avait été volontairement sectionné.

Une enquête a immédiatement été ouverte. Cinq personnes, toutes liées de près ou de loin à la centrale, ont été convoquées.

Madame Lenoir, la directrice de la centrale, a été la première interrogée.
— « Je n’y suis pour rien », a-t-elle déclaré. « J’étais en réunion toute la soirée avec des investisseurs. Saboter la centrale irait totalement contre mes intérêts. »

Le deuxième suspect était Lucas, un ancien technicien licencié quelques semaines plus tôt.
— « Oui, j’étais en colère », a-t-il admis, « mais au moment de la coupure, j’étais chez moi. Mes voisins peuvent le confirmer. »

Ensuite, la police a interrogé Sofia, une ingénieure chargée de la sécurité du site.
— « J’avais accès aux câbles, c’est vrai », a-t-elle expliqué, « mais je travaillais sur un rapport toute la nuit. J’ai même envoyé des emails à 22 h 05. »

Le quatrième suspect était Marc, un électricien indépendant engagé récemment.
— « J’étais près de la centrale », a-t-il reconnu, « mais seulement pour vérifier un transformateur extérieur. Je n’ai touché à rien d’autre. »

Enfin, le maire de la ville a été convoqué.
— « Cette coupure me met dans une position très délicate », a-t-il affirmé. « Pourquoi ferais-je cela juste avant les élections ? »

Alors que tout le monde semblait avoir une excuse crédible, Mister Doggy, le célèbre enquêteur, observait la scène en silence. Il regarda les montres, relut les déclarations et examina les outils retrouvés près de la centrale. Soudain, il leva la tête et déclara :

« J’ai trouvé ! Mais vous devez chercher ! »`;

// Deductive Logic:
// Lenoir: Has clear motive NOT to do it (interests).
// Lucas: Has Alibi (neighbors).
// Sofia: Sent emails at 22:05. Power cut at 22:00. If she was working on a report (likely PC), she might still have battery/UPS, but it's a weak alibi. However, the text for Marc is more damning.
// Marc: Admits being AT the scene (near central) to check a transformer. If the main cable was CUT, he was the only one physically outside/near equipment.
// Prompt explicitly states: "Le coupable est MARC"

const UNIT_10_EXERCISES: Exercise[] = [
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT, question: "À quelle heure la coupure a-t-elle eu lieu ?", options: ["21 h 00", "22 h 00", "Minuit"], correctAnswer: "22 h 00" },
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT, question: "Quelle était la cause de la panne ?", options: ["Un orage", "Un câble sectionné", "Une surchauffe"], correctAnswer: "Un câble sectionné" },
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT, question: "Où était Lucas au moment des faits ?", options: ["Chez lui", "À la centrale", "Au cinéma"], correctAnswer: "Chez lui" },
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT, question: "Quel suspect admet avoir été près de la centrale ?", options: ["Sofia", "Marc", "Le maire"], correctAnswer: "Marc" },
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT, question: "Que faisait Marc officiellement ?", options: ["Il réparait une voiture", "Il vérifiait un transformateur", "Il dormait"], correctAnswer: "Il vérifiait un transformateur" },
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT, question: "Selon l'enquêteur, qui est le coupable ?", options: ["Marc", "Sofia", "Madame Lenoir"], correctAnswer: "Marc" },
];

const UNIT_10_TEXT_FISH = `## **Qui a tué les poissons rouges ?**

*Une enquête de Mister Doggy*

Lorsque la famille **GEMMELÉFRITE** partit en vacances pour trois semaines, elle confia sa vaste demeure à quatre employés de confiance. Tout semblait parfaitement organisé. Pourtant, dès le troisième jour de leur absence, un événement étrange troubla le calme de la maison : les deux poissons rouges du salon furent retrouvés morts dans leur aquarium.

Alerté par un voisin inquiet, **Mister Doggy**, enquêteur réputé pour son sens de l’observation, se rendit immédiatement sur place.

### **Les faits**

L’aquarium n’était ni cassé ni déplacé. L’eau était devenue trouble et une légère odeur chimique persistait dans la pièce. Aucun signe d’effraction n’ayant été constaté, il apparut rapidement que l’auteur des faits se trouvait parmi les personnes chargées de la maison.

### **Les suspects**

**Julien Carcotier**, le jardinier, expliqua qu’il avait passé la matinée dans le jardin à traiter les plantes contre les insectes à l’aide d’un produit puissant. Il reconnut être entré brièvement dans le salon afin de se laver les mains.

**Lisa Hoventime**, le majordome, déclara qu’elle nourrissait les poissons chaque jour avec soin. Elle précisa que, la veille au soir, l’eau de l’aquarium lui avait semblé inhabituellement chaude, comme si un réglage avait été modifié.

**Pum Pang**, la femme de ménage, affirma avoir nettoyé le salon dans la matinée en utilisant uniquement des produits doux. Toutefois, un flacon de détergent industriel se trouvait encore sur son chariot de ménage.

**Bura**, la cuisinière, assura qu’elle n’approchait jamais de l’aquarium. Elle indiqua néanmoins avoir utilisé l’évier du salon pour se débarrasser d’un reste de soupe, la cuisine étant momentanément occupée.

Mister Doggy observa attentivement la pièce, releva chaque détail et nota scrupuleusement les déclarations. Tous semblaient calmes, mais chacun avait eu accès au salon. Le mystère restait entier, et les poissons rouges, silencieux témoins du drame, ne pouvaient plus raconter ce qui leur était arrivé.`;

const UNIT_10_EXERCISES_FISH: Exercise[] = [
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT_FISH, question: "Combien de jours après le départ de la famille le drame a-t-il eu lieu ?", options: ["Le premier jour", "Le troisième jour", "Une semaine après"], correctAnswer: "Le troisième jour" },
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT_FISH, question: "Quel indice a été trouvé dans la pièce ?", options: ["Une fenêtre brisée", "Une odeur chimique", "Des empreintes de pas"], correctAnswer: "Une odeur chimique" },
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT_FISH, question: "Que faisait Julien Carcotier ce matin-là ?", options: ["Il cuisinait", "Il traitait les plantes avec un produit puissant", "Il nettoyait le salon"], correctAnswer: "Il traitait les plantes avec un produit puissant" },
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT_FISH, question: "Pourquoi Julien est-il entré dans le salon ?", options: ["Pour regarder la télé", "Pour se laver les mains", "Pour nourrir les poissons"], correctAnswer: "Pour se laver les mains" },
    { type: 'reading-comprehension', contextText: UNIT_10_TEXT_FISH, question: "Selon les indices, qui a tué les poissons rouges ?", options: ["Julien Carcotier", "Bura", "Lisa Hoventime"], correctAnswer: "Julien Carcotier" },
];

// Helper to create AI-generated units with 8 lessons
const createAiUnit = (idPrefix: string, number: number, title: string, description: string, color: string, lessonTitles: string[]): Unit => {
    return {
        id: idPrefix,
        number: number,
        title: title,
        description: description,
        color: color,
        lessons: lessonTitles.map((t, idx) => ({
            id: `${idPrefix}-l${idx + 1}`,
            index: idx,
            type: idx === 7 ? 'trophy' : (idx % 2 === 0 ? 'star' : 'book'),
            status: LessonStatus.ACTIVE,
            totalLevels: 1,
            completedLevels: 0,
            title: t,
            // Empty exercises triggers the AI generator in LessonOverlay using the title/topic
            exercises: [] 
        }))
    };
};

export const MOCK_UNITS: Unit[] = [
  {
    id: 'u1',
    number: 1,
    title: "Compréhension de l'oral",
    description: "Écouter des dialogues et émissions radio.",
    color: 'bg-duo-blue',
    lessons: [
      { id: 'l1-1', index: 0, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Exercice 1: Vacances', exercises: UNIT_1_EXERCISES_1 },
      { id: 'l1-2', index: 1, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Exercice 2: Internet', exercises: UNIT_1_EXERCISES_2 },
      { id: 'l1-3', index: 2, type: 'trophy', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Exercice 3: Radio', exercises: UNIT_1_EXERCISES_3 },
      { id: 'l1-4', index: 3, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Exercice 4: Tourisme', exercises: UNIT_1_EXERCISES_4 },
    ]
  },
  {
    id: 'u2',
    number: 2,
    title: "Compréhension des écrits",
    description: "Lire et analyser des textes.",
    color: 'bg-duo-green',
    lessons: [
      { id: 'l2-1', index: 0, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Le Marché Bio', exercises: UNIT_2_EXERCISES },
      { id: 'l2-2', index: 1, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'La France (5 min)', exercises: UNIT_2_EXERCISES_FRANCE },
      { id: 'l2-3', index: 2, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Témoignages (Cigarette)', exercises: UNIT_2_EXERCISES_SMOKING },
      { id: 'l2-4', index: 3, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Sentiments (Charlie)', exercises: UNIT_2_EXERCISES_CHARLIE },
    ]
  },
  {
    id: 'u3',
    number: 3,
    title: "Production Écrite",
    description: "Rédiger un texte de 180 mots.",
    color: 'bg-duo-red',
    lessons: WRITING_TOPICS.map((topic, index) => ({
        id: `l3-${index + 1}`,
        index: index,
        type: index % 3 === 0 ? 'trophy' : index % 2 === 0 ? 'star' : 'book',
        status: LessonStatus.ACTIVE,
        totalLevels: 1,
        completedLevels: 0,
        title: topic.title,
        exercises: [{ type: 'writing', question: topic.prompt, correctAnswer: "" }]
    }))
  },
  {
    id: 'u4',
    number: 4,
    title: "Production Orale",
    description: "Présentation et interaction orale.",
    color: 'bg-duo-yellow',
    lessons: [
      { id: 'l4-1', index: 0, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Expression Orale', exercises: [{ type: 'speaking', question: "AI Generated Topic", correctAnswer: "" }] },
    ]
  },
  {
    id: 'u5',
    number: 5,
    title: "Comprendre une conversation",
    description: "Comprendre ce que disent les gens.",
    color: 'bg-purple-500',
    lessons: [
      { id: 'l5-1', index: 0, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Au Restaurant', exercises: UNIT_5_EXERCISES_1 },
      { id: 'l5-2', index: 1, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Entre Amis', exercises: UNIT_5_EXERCISES_2 },
      { id: 'l5-3', index: 2, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Au Travail', exercises: UNIT_5_EXERCISES_1 }, 
      { id: 'l5-4', index: 3, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Transports', exercises: UNIT_5_EXERCISES_2 }, 
      { id: 'l5-5', index: 4, type: 'trophy', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Bilan', exercises: UNIT_5_EXERCISES_1 },
    ]
  },
  {
    id: 'u6',
    number: 6,
    title: "Donner son avis",
    description: "Répondez aux provocations du chien.",
    color: 'bg-orange-500',
    lessons: [
        { id: 'l6-1', index: 0, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Introduction', exercises: UNIT_6_LESSON_1 },
        { id: 'l6-2', index: 1, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Ennemis', exercises: UNIT_6_LESSON_2 },
        { id: 'l6-3', index: 2, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Hygiène', exercises: UNIT_6_LESSON_3 },
        { id: 'l6-4', index: 3, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Nourriture', exercises: UNIT_6_LESSON_4 },
        { id: 'l6-5', index: 4, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Humains', exercises: UNIT_6_LESSON_5 },
        { id: 'l6-6', index: 5, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Activités', exercises: UNIT_6_LESSON_6 },
        { id: 'l6-7', index: 6, type: 'trophy', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Bilan Chien', exercises: UNIT_6_LESSON_7 },
    ]
  },
  {
    id: 'u7',
    number: 7,
    title: "Dire ce qu'on aime",
    description: "Parlez de vos goûts avec Lisa.",
    color: 'bg-pink-500',
    lessons: [
      { id: 'l7-1', index: 0, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Rencontre', exercises: UNIT_7_LESSON_1 },
      { id: 'l7-2', index: 1, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Loisirs & Culture', exercises: UNIT_7_LESSON_2 },
      { id: 'l7-3', index: 2, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Nourriture', exercises: UNIT_7_LESSON_3 },
      { id: 'l7-4', index: 3, type: 'trophy', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Challenge Travail', exercises: UNIT_7_LESSON_4 },
    ]
  },
  {
    id: 'u8',
    number: 8,
    title: "Demander de l'aide",
    description: "Politesse et situations du quotidien.",
    color: 'bg-[#B8F7FF]',
    lessons: [
        { id: 'l8-1', index: 0, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Politesse', exercises: generateUnit8Exercises(U8_L1_BASE) },
        { id: 'l8-2', index: 1, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Directions', exercises: generateUnit8Exercises(U8_L2_BASE) },
        { id: 'l8-3', index: 2, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Magasins', exercises: generateUnit8Exercises(U8_L3_BASE) },
        { id: 'l8-4', index: 3, type: 'trophy', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Challenge', exercises: generateUnit8Exercises(U8_L4_BASE) },
    ]
  },
  {
    id: 'u9',
    number: 9,
    title: "Parler à ses amis",
    description: "Discussions, avis et sorties.",
    color: 'bg-indigo-500',
    lessons: [
        { id: 'l9-1', index: 0, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Présentation', exercises: generateUnit9Content(U9_L1_BASE) },
        { id: 'l9-2', index: 1, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Parler de ses opinions', exercises: generateUnit9Content(U9_L2_BASE) },
        { id: 'l9-3', index: 2, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Sortie au cinéma', exercises: generateUnit9Content(U9_L3_BASE) },
        { id: 'l9-4', index: 3, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Communiquer en voyage', exercises: generateUnit9Content(U9_L4_BASE) },
        { id: 'l9-5', index: 4, type: 'trophy', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Bilan', exercises: generateUnit9Content(U9_L5_BASE) },
    ]
  },
  {
    id: 'u10',
    number: 10,
    title: "Enquêter et raisonner",
    description: "Résolvez le mystère de la ville.",
    color: 'bg-slate-700',
    lessons: [
        { id: 'l10-1', index: 0, type: 'star', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Le Mystère de l\'Électricité', exercises: UNIT_10_EXERCISES },
        { id: 'l10-2', index: 1, type: 'book', status: LessonStatus.ACTIVE, totalLevels: 1, completedLevels: 0, title: 'Qui a tué les poissons ?', exercises: UNIT_10_EXERCISES_FISH },
    ]
  },
  createAiUnit('u11', 11, "Être d'accord", "Exprimez votre accord ou désaccord.", 'bg-duo-green', 
    ["Oui, c'est vrai", "Absolument", "Je suis d'accord", "Pas du tout", "Le débat", "Convaincre", "Nuancer", "Bilan"]
  ),
  createAiUnit('u12', 12, "Réclamer ou ordonner", "Savoir se plaindre et donner des ordres.", 'bg-duo-red', 
    ["Le restaurant", "Mauvais service", "Donner un ordre", "L'impératif", "Se plaindre poliment", "Exiger", "Le remboursement", "Bilan"]
  ),
  createAiUnit('u13', 13, "S'excuser ou pardonner", "Gérer les conflits et les excuses.", 'bg-duo-blue', 
    ["Je suis désolé", "Pardon", "Ce n'est pas grave", "Accepter des excuses", "Reconnaître ses torts", "Se réconcilier", "La politesse", "Bilan"]
  ),
  createAiUnit('u14', 14, "Expliquer et s'exprimer", "Clarifiez vos pensées et arguments.", 'bg-duo-yellow', 
    ["Parce que", "C'est-à-dire", "En effet", "Donner des exemples", "Reformuler", "Préciser", "Conclure", "Bilan"]
  ),
  createAiUnit('u15', 15, "Conseiller ou suggérer", "Aidez les autres avec vos conseils.", 'bg-purple-500', 
    ["Tu devrais", "Si j'étais toi", "Il faut que", "Je te conseille", "Proposer une idée", "L'impératif", "Le subjonctif", "Bilan"]
  ),
  createAiUnit('u16', 16, "Demander la permission", "La politesse et les autorisations.", 'bg-orange-500', 
    ["Puis-je ?", "Est-ce que je peux ?", "Vous permettez ?", "C'est interdit", "C'est autorisé", "Le règlement", "S'il vous plaît", "Bilan"]
  ),
  createAiUnit('u17', 17, "Rédiger une lettre", "Formules et structure de l'écrit.", 'bg-pink-500', 
    ["Cher Monsieur", "Cordialement", "L'objet de la lettre", "Formules de politesse", "Lettre formelle", "Lettre amicale", "Signer", "Bilan"]
  ),
  createAiUnit('u18', 18, "Réseaux sociaux", "Commenter et interagir en ligne.", 'bg-indigo-500', 
    ["Poster un commentaire", "J'aime", "Partager", "Hashtags", "Donner son avis", "Répondre", "Les émojis", "Bilan"]
  ),
  createAiUnit('u19', 19, "Remercier ou féliciter", "Exprimez votre gratitude et joie.", 'bg-teal-500', 
    ["Merci beaucoup", "Bravo !", "Félicitations", "C'est génial", "Je te remercie", "Joyeux anniversaire", "Bon travail", "Bilan"]
  )
];

export const MOCK_STATS = {
  streak: 12,
  gems: 450,
  hearts: 5
};